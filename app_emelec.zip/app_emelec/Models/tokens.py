from odoo import fields, models

class tokens(models.Model):

	_name = 'tokens'
	_description= "Detalles de los tokens"

	cedula = fields.Char(string='Cedula', required=True)
	tokens = fields.Char(string='Celular', required=True)
