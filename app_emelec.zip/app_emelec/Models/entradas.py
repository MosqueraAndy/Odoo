from odoo import fields, models

class Entradas(models.Model):

	_name = 'entradas'
	_description= "Entradas"

 	id_partido = fields.Many2one('partidos','Partido', required=True)
 	id_locacion = fields.Many2one('localidades','Localidad', required=True) 