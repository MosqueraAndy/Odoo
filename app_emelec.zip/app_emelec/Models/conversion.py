## -*- coding: utf-8 -*-

from odoo import fields, models

class Conversion(models.Model):

	_name = 'conversion'
	_description= "Conversión del valor en dólares a millas"

	name = fields.Float('Código de Conversión', required=True) 
	cant_entradas = fields.Integer('Cantidad Límite de Entradas')
	max_trans = fields.Integer('Número máximo de transferencia')
 	
 	estado = fields.Boolean('Estado',default=True)
