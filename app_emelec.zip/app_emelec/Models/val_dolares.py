# -*- coding: utf-8 -*-

from odoo import fields, models


 
class ValDolares(models.Model):
	_name = 'valdolares'
	_description = 'Valor en dólares de entradas al partido de Emelec'

	name = fields.Float('Valor en Dólares de Entradas', required=True)
