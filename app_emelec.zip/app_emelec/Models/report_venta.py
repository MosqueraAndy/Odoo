# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

#
# Please note that these reports are not multi-currency !!!
#

from odoo import api, fields, models,tools
class ReportesVentas(models.Model):
    _name = "reportes.venta"
    _auto = False
   # _order = 'date_order desc, price_total desc'

    partner_id = fields.Many2one('res.partner', 'cedula')
    date_order = fields.Datetime('Fecha Compra', readonly=True, help="Date on which this document has been created", oldname='date')
    fecha_partidos=fields.Char('Fecha Partido')
    #fecha_partido =fields.Many2one('sale.order','fecha partido')
    localidad=fields.Char('Localidad')
    cant_entradas=fields.Float('Cantidad Entradas')
    val_dolares=fields.Float('Valor Entradas')
    ####val_millas=fields.Many2one('sale.order.line','Cantidad Millas')
    cod_aprob=fields.Char('Numero Canje/Aprobacion')
    val_millas=fields.Float('Millas')
   
    #=========================VISTA==================================================


    @api.model_cr
    def init(self):
        tools.drop_view_if_exists(self._cr, 'reportes_venta')

        self._cr.execute(""" create view reportes_venta as (
                        
           select 
           so.partner_id,
           so.date_order,
           so.fecha_partido as fecha_partidos,
           sol.localidad, 
           so.cant_tot_entradas as cant_entradas,
           sol.val_dolares,
           pu.cod_aprob,
           pu.id,
           (sol.val_dolares) * (select name::numeric from conversion limit 1 ) as val_millas
           from 
           sale_order so , 
           sale_order_line sol, purchase_order pu
           where so.id = sol.order_id and so.compra_id=pu.id)
       
                              """)
