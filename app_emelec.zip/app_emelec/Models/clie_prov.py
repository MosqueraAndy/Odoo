# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
from odoo import fields, models, api, _
from datetime import timedelta
from odoo.exceptions import ValidationError, except_orm

class Padre(models.Model):
	_description = "Clase Partner Proveedores y Clientes"
	_inherit = 'res.partner'
	apellido=fields.Char(string='Apellido')	
	cedula=fields.Char(string='Cedula')
	celular=fields.Char(string='Celular')
	email=fields.Char(string='Correo')
	active=fields.Boolean(string='Activo', default=True)
	company_type=fields.Selection([('person', 'Cliente'), ('company', 'Proveedor')],String='Company Type',compute='_compute_company_type', readonly=False)