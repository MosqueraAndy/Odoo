# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import fields, models, api
from datetime import timedelta
from odoo.exceptions import UserError, ValidationError
import datetime
from odoo.tools.misc import formatLang 

class VentaCab(models.Model):
    _inherit = 'sale.order'
    partido = fields.Char('Partido')
    fecha_partido = fields.Char('Fecha de Partido')
    hr_partido = fields.Char('Hora de Partido')
    cant_tot_entradas = fields.Float('Cantidad Tot. Entradas')


    compra_id=fields.Many2one('purchase.order','compra')
    order_line=fields.One2many('sale.order.line','order_id',string="Ventas", ondelete='cascade',store=True )
    

class VentaDet(models.Model):

    _inherit = 'sale.order.line'

    order_id=fields.Many2one('sale.order',string="line" , ondelete='cascade',store=True)
    num_entrada = fields.Char('Numero de Entrada')
    localidad = fields.Char('Localidad')
    partido = fields.Char('Partido')
    fecha_partido = fields.Char('Fecha de Partido')
    hr_partido = fields.Char('Hora de Partido')
    val_dolares = fields.Float('Valor Dólares')  
    val_millas = fields.Char('Valor Millas') #Campo añadido se calculará con el valor en dólares * el factor de conversión.
    
    amount_untaxed = fields.Monetary(string='Untaxed Amount', store=True, readonly=True, compute='_amount_all_claro', track_visibility='always')
    amount_tax = fields.Monetary(string='Taxes', store=True, readonly=True, compute='_amount_all_claro', track_visibility='always')
    amount_total = fields.Monetary(string='Total', store=True, readonly=True, compute='_amount_all_claro', track_visibility='always', copy=False)
    valor_monto = fields.Monetary(string='Valor Total', store=True, readonly=True, compute='_amount_all_claro', track_visibility='always', copy=False)

    # @api.onchange('localidad')
    # def cal_valmillas(self): 
    #     self.env.cr.execute ("""Select (comp.val_dolares * conv.name) valmillas , comp.id from sale_order_line comp, conversion conv where estado='true' """)
    #     print """Select (comp.val_dolares * conv.name) valmillas from sale_order_line comp, conversion conv where estado='true' """
    #     res_solicitud=self.env.cr.dictfetchall()
        
    #     for l in range(0,len(res_solicitud)):

    #         self.env.cr.execute =("""update sale_order_line set val_millas='{0}' where id={1}""".format(res_solicitud[l]['valmillas'],res_solicitud[l]['id']))
    #         print """update sale_order_line set val_millas='{0}' where id={1}""".format(res_solicitud[l]['valmillas'],res_solicitud[l]['id']),"ACT"
    
    # @api.depends('order_id')
    # def _amount_all_claro(self):
    #     print ""

    #     for order in self:
    #          amount_untaxed = amount_tax = 0.0
    #          for line in order.order_id:
    #              amount_untaxed += line.val_dolares
    #               # FORWARDPORT UP TO 10.0
    #              if order.company_id.tax_calculation_rounding_method == 'round_globally':
    #                   #price = line.price_unit * (1 - (line.discount or 0.0) / 100.0)
    #                  taxes = line.tax_id.compute_all(price, line.order_id.currency_id, line.product_uom_qty, product=line.product_id, partner=order.partner_shipping_id)
    #                  amount_tax += sum(t.get('amount', 0.0) for t in taxes.get('taxes', []))

    #          order.update({
    #               'amount_untaxed': order.pricelist_id.currency_id.round(amount_untaxed),
    #               'amount_tax': order.pricelist_id.currency_id.round(amount_tax),
    #               'amount_total': amount_untaxed + amount_tax,
    #           })
    #     return self.amount_total


    
    # @api.onchange('order_id')
    # def _compute_total_monto(self):
    #     self.monto_total=sum(line.val_dolares for line in self.sale_order_line)
    #     return self.monto_total