# -*- coding: utf-8 -*-

from odoo import fields, models


 
class Localidades(models.Model):
    _name = 'localidades'
    _description = "Localizaciones en el Estadio"

    name = fields.Char('Nombre de Localidad', required=True)
    cod=fields.Integer('Código',required=True) 
    