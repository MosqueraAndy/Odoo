# -*- coding: utf-8 -*-

from odoo import fields, models


 
class Millas(models.Model):
    _name = 'millas'
    _description = "Valor de Entradas en Millas"

    name = fields.Char('Número de Millas', required=True)
    # cod=fields.Char('Código',required=True)
