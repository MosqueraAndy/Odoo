# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
from odoo import fields, models, api, _
from datetime import timedelta
from odoo.exceptions import ValidationError, except_orm
import re

class personas_emelec(models.Model):
 
	_name = 'personas.emelec'
	_description = "Listado de cliente" 

	#persons= fields.Many2one('rea.partner', String='Personas' )
	clientes= fields.Many2many('res.partner', 'person_relacion_rel','id_solicitud','id_partner',string='Clientes')