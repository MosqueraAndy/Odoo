
# -*- coding: utf-8 -*-
from itertools import groupby
import xml.etree.ElementTree as ET

from odoo import api, fields, models, _
from odoo.exceptions import UserError
from odoo.tools import float_is_zero, float_compare, DEFAULT_SERVER_DATETIME_FORMAT
from odoo.tools.misc import formatLang 
from odoo.fields import Integer
import odoo.addons.decimal_precision as dp
import datetime
import time
from odoo.exceptions import ValidationError, except_orm
from odoo.exceptions import UserError
from create_excel import *
from StringIO import StringIO
import base64, time
import commands
import os


class SaleOrder(models.Model):
  _inherit = 'sale.order'
  _description = "reporte de ventas Emelec"
  #_order = 'date_order desc, id desc'
     
##############--------------GENERAR EXCEL---------------####################



  @api.multi
  def generar_xls(self):
      dct=self.generate_file()

      self.env.cr.execute("""select * from ir_attachment where res_id={0} and res_model='{1}'""".format(self.id,'sale.order'))
      res=self.env.cr.dictfetchall()    
      obj=self.env['sale.order'].browse(self.id)
      if len(res) == 0:
          obj_attach=self.env['ir.attachment']
          obj_xls_attach=obj_attach.create({'name':dct['xls_filename'],
                                            'res_model':'sale.order',
                                            'res_id':self.id,
                                            'datas':dct['archivo_xls'],
                                            'type':'binary',
                                            'datas_fname':dct['xls_filename']})
          
      else:
          obj_attach=self.env['ir.attachment'].browse(res[0]['id'])
          obj_xls_attach=obj_attach.write({'name':dct['xls_filename'],
                                            'res_model':'sale.order',
                                            'res_id':self.id,
                                            'datas':dct['archivo_xls'],
                                            'type':'binary',
                                            'datas_fname':dct['xls_filename']})

  @api.multi
  def generar_pdf(self):
      dct=self.convert_pdf()

      self.env.cr.execute("""select * from ir_attachment where res_id={0} and res_model='{1}'""".format(self.id,'sale.order'))
      res=self.env.cr.dictfetchall()    
      obj=self.env['sale.order'].browse(self.id)
      if len(res) == 0:
          obj_attach=self.env['ir.attachment']
          obj_xls_attach=obj_attach.create({'name':dct['xls_filename'],
                                            'res_model':'sale.order',
                                            'res_id':self.id,
                                            'datas':dct['archivo_xls'],
                                            'type':'binary',
                                            'datas_fname':dct['xls_filename']})
          self.env.cr.execute("""insert into sale.order(id, attachment_id) values ({0},{1})""".format(self.id,obj_xls_attach.id))
          
      else:
          obj_attach=self.env['ir.attachment'].browse(res[0]['id'])
          obj_xls_attach=obj_attach.write({'name':dct['xls_filename'],
                                            'res_model':'sale.order',
                                            'res_id':self.id,
                                            'datas':dct['archivo_xls'],
                                            'type':'binary',
                                            'datas_fname':dct['xls_filename']})

##############--------------GENERAR PDF---------------####################
  # @api.multi
  # def convert_pdf(self):
  #     dct_=self.generate_file()

  #     obj=self.env['ir.attachment']
  #     obj_xls=obj.create({'name':dct_['xls_filename'],'datas':dct_['archivo_xls'],'auto':'Auto - Vehiculos','casa':'Casa - Habitacion','datas_fname':dct_['xls_filename']})

  #     direccion_xls=obj._get_path(obj_xls.datas,obj_xls.checksum)[1]
  #     nombre_bin=obj_xls.checksum
  #     nombre_archivo=obj_xls.datas_fname
  #     os.chdir(direccion_xls.rstrip(nombre_bin))
  #     os.rename(nombre_bin,nombre_archivo)

  #     commands.getoutput(""" libreoffice --headless --convert-to pdf *.xlsx""") 


  #     with open(direccion_xls.rstrip(nombre_bin)+nombre_archivo.split('.')[0]+'.pdf', "rb") as f:
  #         data = f.read()
  #         file= data.encode("base64")


  #     dct={'xls_filename':nombre_archivo.split('.')[0]+'.pdf','archivo_xls':file}

  #     os.rename(nombre_archivo,nombre_bin)


  #     obj_xls.unlink()


  #     return dct

  #######################---------FUNCION GENERAR EXCEL-----------#######################
  @api.multi
  def generate_file(self):
    fp = StringIO()

      
    workbook = self.crear_excel1()
    workbook.save(fp)
      
    fecha = datetime.datetime.strftime(datetime.datetime.now(), '%Y-%m-%d %H%M%S')


    #dct={
    #  'auto': 'Auto - Vehiculos',
    #  'casa': 'Casa - Habitacion',
    #False: "",
    #}
  
    filename = 'Reporte de ventas'+'.xlsx'
    return  {
        'xls_filename': filename,
        'archivo_xls': base64.b64encode(fp.getvalue())
    } 


  def crear_excel1(self):
    wb = crear_wb()
    self.crear_hautovehiculo(wb)
    return wb 

  def crear_hautovehiculo(self, wb):
    sheet_hautovehiculo = crea_hoja(wb, unicodeText(u'Reportes Ventas'), 0)
    sheet_view = openpyxl.worksheet.SheetView()
    sheet_view.zoomScale = "65"
    sheet_view.zoomScaleNormal = "65"
    sheet_hautovehiculo.sheet_view = sheet_view
    sheet_hautovehiculo.zoomScale = "65" 

    #self.env.cr.execute("select id,imag from sale_order where tipo='auto' and id={0}".format(self.id))        
    #item_imag = self.env.cr.dictfetchall()

    #obj=self.env['sale.order'].browse(self.id)

    # for a in item_imag:
    #   obj_imagen=self.env['ir.attachment'].create({'name': 'impronta.png',
    #                               'type': 'binary',
    #                               'datas': obj.imag,
    #                               'res_model': 'sale.order',
    #                               'res_id': a['id'],
    #                               'mimetype': 'image/png',
    #                               'datas_fname':'imagen.png',
    #                               })
    # direccion=obj_imagen._get_path(obj_imagen.datas,obj_imagen.checksum)[1]

    self.env.cr.execute("""select so.num_reporte,rp.name as cliente,
                                  so.ced,so.descrip_doc,so.street,so.email,so.mobile,
                                  so.placa,so.propiet,so.date_order,so.fech_insp,so.dirinspeccion,so.v_auto,
                                  so.v_periododanio,so.v_permiso,so.v_hasta,so.v_anombrede,so.v_tonelaje,so.v_gravamen,
                                  so.v_marca,so.v_motor,so.v_modelo,so.v_chasis,so.v_tipo,so.v_placa,so.v_aniodelcarro,
                                  so.v_uso,so.v_color,so.v_ocupantes,so.v_puertas,so.v_origen,so.v_cilindros,so.v_transmision,
                                  so.v_direccion,so.v_energia,so.v_fechadcompra,so.v_kilometraje,so.marcacion,so.v_vstandard,so.v_vextras,
                                  so.v_vtotal,so.ponde_doc,so.ponde_edad,so.ponde_uso,so.ponde_kilo,so.ponde_meca,so.ponde_mant,
                                  so.ponde_carr,so.ponde_seg,so.v_punttot,so.v_calificacion,so.reporte_fotog,so.v_observacionesvc,so.imag
                                  from res_partner rp, sale_order so 
                                  where so.partner_id=rp.id and so.tipo='auto' and so.id={0}""".format(self.id))        
    item_a = self.env.cr.dictfetchall()

    self.env.cr.execute("""select so.num_reporte,rp.name as solicitado
                                  from res_partner rp, sale_order so 
                                  where so.tipo='auto' and so.name_comp=rp.commercial_partner_id  and so.id={0}""".format(self.id))        
    item_p = self.env.cr.dictfetchall()
    #######------QUERY PARA INSPECTOR
    self.env.cr.execute("""select rs.partner_id,so.id,rp.commercial_partner_id,rp.name as inspector
                                  from res_partner as rp, res_users as rs ,sale_order as so
                                  where rp.id=rs.partner_id and so.insp_asig=rs.id and so.id={0}""".format(self.id))        
    item_insp = self.env.cr.dictfetchall()

    self.env.cr.execute("""select ca.id,pt.name as accesorio,ca.tipo_acc,ca.estado_acc,ca.v_acc_cant,ca.v_acc_marca,ca.v_acc_modelo,
                                          ca.v_acc_vnuevo,ca.v_acc_observaciones
                                          from product_template pt, caracteristicas_accesorios ca 
                                          where pt.id=name_acc and ca.id_caract={0}""".format(self.id))        
    item_acc = self.env.cr.dictfetchall()

    self.env.cr.execute("""select ca.id,pt.name as seguridad,ca.v_seg_activo,ca.v_acc_cant,ca.v_acc_marca,ca.v_acc_modelo,
                                          ca.v_acc_observaciones
                                          from product_template pt, caracteristicas_seguridad ca 
                                          where pt.id=name_seg and ca.id_caract={0}""".format(self.id))      
    item_seg = self.env.cr.dictfetchall()

    self.env.cr.execute("""select ca.id,pt.name as carroceria,ca.c_carro
                                          from product_template pt, caracteristicas_carroceria ca 
                                          where pt.id=name_car and ca.id_caract={0}""".format(self.id))       
    item_carr = self.env.cr.dictfetchall()    
    ############-----EVALUACION
    self.env.cr.execute("""select ca.name,ca.ponderacion from calif_auto ca, sale_order so
        where ca.califi=so.documentacion_eva and so.id={0} order by ca.id""".format(self.id))        
    item_doc = self.env.cr.dictfetchall()

    self.env.cr.execute("""select ca.name,ca.ponderacion from calif_auto ca, sale_order so
        where ca.califi=so.edad_eva and so.id={0} order by ca.id""".format(self.id))        
    item_edad = self.env.cr.dictfetchall()

    self.env.cr.execute("""select ca.name,ca.ponderacion from calif_auto ca, sale_order so
        where ca.califi=so.uso_eva and so.id={0} order by ca.id""".format(self.id))        
    item_uso = self.env.cr.dictfetchall()

    self.env.cr.execute("""select ca.name,ca.ponderacion from calif_auto ca, sale_order so
        where ca.califi=so.kilometraje_eva and so.id={0} order by ca.id""".format(self.id))        
    item_kilo = self.env.cr.dictfetchall()

    self.env.cr.execute("""select ca.name,ca.ponderacion from calif_auto ca, sale_order so
        where ca.califi=so.mecanica_eva and so.id={0} order by ca.id""".format(self.id))        
    item_meca = self.env.cr.dictfetchall()

    self.env.cr.execute("""select ca.name,ca.ponderacion from calif_auto ca, sale_order so
        where ca.califi=so.mantenimiento_eva and so.id={0} order by ca.id""".format(self.id))        
    item_mant = self.env.cr.dictfetchall()

    self.env.cr.execute("""select ca.name,ca.ponderacion from calif_auto ca, sale_order so
        where ca.califi=so.carroceria_eva and so.id={0} order by ca.id""".format(self.id))        
    item_car = self.env.cr.dictfetchall()

    self.env.cr.execute("""select ca.name,ca.ponderacion from calif_auto ca, sale_order so
        where ca.califi=so.seguridad_eva and so.id={0} order by ca.id""".format(self.id))        
    item_segu = self.env.cr.dictfetchall()

    crear_hautovehiculo(sheet_hautovehiculo,item_a,item_p,item_insp,item_acc,item_seg,item_carr,item_doc,item_edad,item_uso,item_kilo,item_meca,item_mant,item_car,item_segu,direccion,item_imag)
    #crear_hautovehiculo(sheet_hautovehiculo,item_a,item_p,item_insp,item_acc,item_seg,item_carr,item_doc,item_edad,item_uso,item_kilo,item_meca,item_mant,item_car,item_segu)
    obj_imagen.unlink()