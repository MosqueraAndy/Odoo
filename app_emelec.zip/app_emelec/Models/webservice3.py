#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Created on 28/11/2017

@author: righttek
"""
import socket
from datetime import datetime
import web
from soaplib.wsgi_soap import SimpleWSGISoapApp
from soaplib.service import soapmethod
from soaplib.serializers import primitive as soap_types
from xml.dom import minidom
import logging.handlers
import os
import psycopg2
import psycopg2.extras
import psycopg2.extensions
from psycopg2.extensions import ISOLATION_LEVEL_AUTOCOMMIT, ISOLATION_LEVEL_READ_COMMITTED, ISOLATION_LEVEL_REPEATABLE_READ
from psycopg2.pool import PoolError
from warnings import catch_warnings
import unicodedata
import fcntl
import struct
import base64

urls = (
        "/emelec_app", "AnexoService",
        "/emelec_app.wsdl", "AnexoService",
    )

render = web.template.Template("$def with (var)\n$:var")

class SoapService(SimpleWSGISoapApp): 
    
    """Class for webservice """
    """
    second (s)
    minute (m)
    hour (h)
    day (d)
    w0-w6 (weekday, 0=Monday) 
    """
    allowed_methods = ['get', 'post', 'put', 'delete', 'options']
    ruta_log = os.getcwd()+'/LogEmelec/'
    if not os.path.exists(ruta_log): os.makedirs(ruta_log)
    anx_log = ruta_log+'emelec_app.log'
    
    logger=logging.getLogger('LogAnexo')
    logger.setLevel(logging.DEBUG)
    handler = logging.handlers.TimedRotatingFileHandler(filename=anx_log, when="d", interval=1, backupCount=5)
    formatter = logging.Formatter(fmt='%(asctime)s - %(name)s - %(levelname)s - %(message)s',datefmt='%y-%m-%d %H:%M:%S')
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    #conn=psycopg2.connect(database='calendar',user='odoo',password='admin',host='localhost')
    
    def conexion(self): 
        try:
            #conn=psycopg2.connect(database='App_Emelec',user='odoo',password='odoo',host='172.17.0.2')
            conn=psycopg2.connect(database='emelec_app',user='odoo',password='odoo',host='172.17.0.4')
            return conn
        except Exception as e: 
             
            print"Error en conexion: ",e
            self.logger.error('Error de conexion')

        
    @soapmethod(soap_types.String,_returns = soap_types.String)
    def consulta(self, conversion):
        dict={'factor':'','entrada':''}
    
        self.logger.info('-------Inicia Proceso APP------')
        #inicializacion
        codigo=None
        try:
            #conexion
            conn=self.conexion()
            cur=conn.cursor()
            
            #consulta filtros
            sql="""select name,cant_entradas from conversion order by create_date desc"""
            cur.execute(sql)
            result=cur.fetchone()
            codigo=result[0]
            entrada=result[1]

            dict["factor"]=codigo
            dict["entrada"]=entrada
            dict=str(dict)
            return dict
            
        except Exception as e:
            self.logger.error("Error en consulta"+str(e))
            print "Excepción en consulta",e 
               
        finally:
            cur.close()
            conn.close()

    #MÉTODO QUE REGISTRARÁ LA PARTE DE COMPRAS
    @soapmethod(soap_types.String,soap_types.String,soap_types.String,soap_types.String,soap_types.String,_returns = soap_types.Integer)
    #def compra(self,partner_id,product_id,id_compra,fecha_compra,localidad,partido,cantidad,price_unit,price_subtotal,amount_total):
    def compra(self,partido,fecha_partido,hr_partido,cant_tot_entradas,cedula):  

        try: 
            conn=self.conexion()
            cur=conn.cursor()
            result=cur.fetchall 
            query="""select id, cedula from res_partner
                        where cedula=%s"""
            cur.execute(query,(cedula,))
            result=cur.fetchone()

            if result==None:
                sql= """Insert into res_partner(cedula,notify_email,invoice_warn,picking_warn,purchase_warn,sale_warn)
                        values (%s,'none','no-message','no-message','no-message','no-message')"""
                cur.execute(sql,(cedula,))
                conn.commit()
                query="""select id, cedula from res_partner
                            where cedula=%s"""
                cur.execute(query,(cedula,)) 
                result=cur.fetchone()
                    #.write({cedula:'result'})
                id_clie= result[0]
            else:
                id_clie= result[0] 

            querycomp="""Insert into purchase_order(currency_id,date_order,partner_id,
                                                        picking_type_id ,
                                                        company_id,
                            name,fecha_partido,hr_partido,cant_tot_entradas, state)
                            values( 1, now() , %s, 1 , 1 , %s , %s, %s , %s,'draft')""" 
            cur.execute(querycomp,(id_clie,partido,fecha_partido,hr_partido,cant_tot_entradas))
            conn.commit()
            query= """select max(id) from purchase_order""" 
            cur.execute(query)
            result=cur.fetchone()
            order_id=result[0]
            #===================================================================
            # VENTAS CAB
            #===================================================================
            # queryvent="""Insert into sale_order(date_order,partner_id, picking_policy ,partner_invoice_id,name,
            #             partner_shipping_id,warehouse_id,state,fecha_partido,hr_partido,cant_tot_entradas,partido)
            #             values( now() , %s, 'direct' , %s , SO , %s, 1 ,'draft',%s,%s,%s,%s)""" 
            queryvent="""Insert into sale_order(date_order,partner_id, picking_policy ,name,state,fecha_partido,hr_partido,cant_tot_entradas,partido)
                        values( now() , {0}, 'direct' , {1} , SO , {2}, 1 ,'draft',{3},{4},{5},{6})"""  
            
            print queryvent.format(id_clie,id_clie,id_clie,  fecha_partido,hr_partido,cant_tot_entradas,partido,order_id )        

            cur.execute(queryvent.format(id_clie,id_clie,id_clie,  fecha_partido,hr_partido,cant_tot_entradas,partido,order_id ))
            conn.commit()
            #===================================================================
            # VENTAS CAB
            #===================================================================
   
            return order_id

        except Exception as e:  
            self.logger.error("Fallo de insert en cabecera compras")
            print "ERROR DE INSERCIÓN CABECERA DE COMPRA"+str(e)
            return -1

        finally:
            cur.close()
            conn.close()

    #MÉTODO QUE REGISTRARÁ EL DETALLE DE LA COMPRA
    @soapmethod(soap_types.Integer, soap_types.String,soap_types.String,soap_types.String,soap_types.String,soap_types.String,soap_types.Float,_returns=soap_types.Integer)
    def detcompra(self,id_compra,num_entrada,localidad,partido,fecha_partido,hr_partido,val_dolares):
        try:
            conn=self.conexion() 
            cur=conn.cursor()
            result=cur.fetchall
            # query_id="""select id from purchase_order where name=%s and fecha_partido=%s"""
            # cur.execute(query_id,(partido,fecha_partido))
            # result=cur.fetchone()
            # order_id=result[0]

            #ENTRADA
            
            querydet="""Insert into purchase_order_line(date_planned,product_uom,price_unit,product_qty,product_id,order_id,num_entrada,localidad,name,fecha_partido,hr_partido,val_dolares)
                    values('2017-12-20',1,2,1,1,%s,%s,%s,%s,%s,%s,%s)""" 
            cur.execute(querydet,(id_compra,num_entrada,localidad,partido,fecha_partido,hr_partido,val_dolares)) 
            conn.commit()
            
            #===================================================================
            # DETALLE DE ENTRADAS VENTAS
            #===================================================================
            query= """select max(id) from sale_order""" 
            cur.execute(query)
            result=cur.fetchone()
            order_id=result[0]
            
            queryvetdet = """ Insert into purchase_order_line(product_uom,price_unit,product_uom_qty,product_id,order_id,customer_lead,num_entrada,localidad,name,fecha_partido,hr_partido,val_dolares)
                    values(1,(select id from product_template where name = 'ENTRADAS'),1,%s,%s,0,%s,%s,%s,%s,%s,%s)"""
            
            cur.execute(queryvetdet,(val_dolares ,order_id,  num_entrada,localidad,partido,fecha_partido,hr_partido,val_dolares))
            conn.commit()
            #===================================================================
            # DETALLE DE ENTRADAS VENTAS
            #===================================================================
            
            return 200

        except Exception as e:
            self.logger.error("Fallo en insert detalle de compra")
            print "ERROR DE INSERCIÓN DETALLE DE COMPRA"+str(e)
            return -1
 
        finally: 
            cur.close()
            conn.close()

    #MÉTODO QUE REGISTRÁ LA CABECERA DE LA VENTA #DESDE AQUÍ
    # @soapmethod(soap_types.String,soap_types.String,soap_types.String,soap_types.String,soap_types.String,_returns = soap_types.Integer)
    # def venta(self,partido,fecha_partido,hr_partido,cant_tot_entradas,cedula):  

    #     try: 
    #         conn=self.conexion()
    #         cur=conn.cursor()
    #         result=cur.fetchall 

    #         queryvent="""Insert into sale_order(partido,fecha_partido,hr_partido,cant_tot_entradas,cedula)
    #         values(self,%s,%s,%s,%s,%s)"""  
    #         cur.execute(())
    #         conn.close()

    #MÉTODO QUE REGISTRÁ EL DETALLE DE LA VENTA



class AnexoService(SoapService):
    """Class for web.py """
    
    def start_response(self,status, headers):
        web.ctx.status = status
        
        for header, value in headers:
            web.header(header, value)

    def GET(self):
        response = super(SimpleWSGISoapApp, self).__call__(web.ctx.environ, self.start_response)
        return render("\n".join(response))

    def POST(self):
        response = super(SimpleWSGISoapApp, self).__call__(web.ctx.environ, self.start_response)
        return render("\n".join(response))
    
    def OPTIONS(self):
        
        return 
    
app=web.application(urls, globals())

if __name__ == "__main__":
    app.run()
