# -*- coding: utf-8 -*-

from odoo import fields, models

class Partido(models.Model):

	_name = 'partidos'
	_description= "Nombre del partido a jugar"

	name = fields.Char('Nombre de Partido', required=True)
 	cod_partido = fields.Char('Código') 