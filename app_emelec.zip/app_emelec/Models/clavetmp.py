## -*- coding: utf-8 -*-

from odoo import fields, models

class ClaveTMP(models.Model):

	_name = 'clavetmp'
	_description= "clave temporales"

	cedula=fields.Char('Cedula', required=True) 
	clave=fields.Char('Clave') 
