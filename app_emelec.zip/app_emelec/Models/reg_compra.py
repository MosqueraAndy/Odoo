# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import fields, models, api, _
from datetime import timedelta
from odoo.exceptions import UserError, ValidationError
import datetime
from odoo.tools.misc import formatLang 

class PurchaseOrder(models.Model):

	_inherit = 'purchase.order'
	  #precio_total = fields.Char('') => amount_total

	partido = fields.Char('Partido')
	fecha_partido = fields.Char('Fecha de Partido')
	hr_partido = fields.Char('Hora de Partido')
	cant_tot_entradas = fields.Float('Cantidad Tot. Entradas')
	fecha_compra = fields.Char('Fecha Compra')
	cod_aprob=fields.Char('Código de Aprobación')


		
class PurchaseOrderLine(models.Model):

    _inherit = 'purchase.order.line'

    num_entrada = fields.Char('Numero de Entrada')
    localidad = fields.Char('Localidad')
    partido = fields.Char('Partido')
    fecha_partido = fields.Char('Fecha de Partido')
    hr_partido = fields.Char('Hora de Partido')
    val_dolares = fields.Float('Valor Dólares')
    val_millas = fields.Float('Valor Millas')  

	#estado = fields.Boolean('Estado')
