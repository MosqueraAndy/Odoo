from odoo import fields, models

class detalle_entrada(models.Model):

	_name = 'estado.entrada'
	_description= "Detalles de las entradas"

	cedula = fields.Char(string='Cedula', required=True)
	celular = fields.Char(string='Celular', required=True)
 	emisor = fields.Char(string='emisor')
 	entrada = fields.Char(string='Entrada', required=True)
 	estado= fields.Char(string='Estado', required=True)
 	fecha= fields.Date(string='Fecha', required=True)
 	compra_id=fields.Integer(string='Compra_id', required=True)   
 	evento_id=fields.Integer(string='Evento_id', required=True) 
 	beneficiario=fields.Char(string='Beneficiario') 