#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Created on 28/11/2017

@author: righttek
"""
from flask import Flask, request, jsonify
import logging.handlers
import unicodedata
from datetime import datetime,timedelta,date
import psycopg2
import os
import time
import decimal
import sys
import datetime 

app = Flask(__name__)
# fechaActual= (time.strftime("%Y-%m-%d"))
# archivo= 'aarchivo'+fechaActual+'.log'
# ruta='/tmp/LogProyecto/'+archivo+''
# ObjArchivo = open(ruta, 'wb')  
# logging.basicConfig(filename=ruta,level=logging.DEBUG)
# logging.debug('Este mensaje debe ir al archivo de regitro')
# logging.info('Este tambien')
# logging.warning('Y este')


ruta_log = os.getcwd()+'/LogProyecto/'
print ruta_log
if not os.path.exists(ruta_log): os.makedirs(ruta_log)

print 'no ingresa al if'
anx_log = ruta_log+'proyecto_p.log'   
logger=logging.getLogger('LogProyecto')
print 'logger ',logger
logger.setLevel(logging.DEBUG)
handler = logging.handlers.TimedRotatingFileHandler(filename=anx_log, when="d", interval=1, backupCount=5)
print handler
formatter = logging.Formatter(fmt='%(asctime)s - %(name)s - %(levelname)s - %(message)s',datefmt='%y-%m-%d %H:%M:%S')
handler.setFormatter(formatter)
logger.addHandler(handler)
def conexion(): 

        try:
            conn=psycopg2.connect(database='azulmaticoProd',user='odoo',password='odoo',host='172.17.0.2')
            return conn
        except Exception as e: 
             
            print"Error en conexion: ",e
            logger.error('Error de conexion')



@app.route("/insertarToken", methods=["POST"])
def insertarToken():
    cedula = request.json['cedula']
    tokens = request.json['tokens']
    dicc={'codigo':000,'descripcion':''}
    
    logger.info('-------Inicia Proceso APP------')
    #inicializacion
    codigo=None
    try:
        #conexion
        conn=conexion()
        cur=conn.cursor()
        consultaCedula="""select cedula from tokens where cedula='{0}' """.format(cedula)
        print 'consultar S',consultaCedula
        cur.execute(consultaCedula)
        resultado= cur.fetchall()
        
        if resultado==[]:

            sql="""insert into tokens(cedula,tokens) values ('{0}','{1}')""".format(cedula,tokens.encode('UTF-8'))
            cur.execute(sql)
            conn.commit()

            dicc["codigo"]=200
            dicc["descripcion"]="Tokens registrado con Exito"
            return jsonify(dicc)
        
        if resultado!=[]:

            sql="""update tokens set tokens='{0}' where cedula='{1}'""".format(tokens.encode('UTF-8'),cedula)
            cur.execute(sql)
            conn.commit()

            dicc["codigo"]=200
            dicc["descripcion"]="Tokens actualizado con Exito"
            return jsonify(dicc)

    except Exception as e:
        logger.error("Error "+str(e))
        print "Excepción en consulta",str(e)
        dicc["codigo"]=400
        dicc["descripcion"]="no se pudo registrar el tokens "+str(e)+""
        return jsonify(dicc)
           
    finally:
        cur.close()
        conn.close()


@app.route("/consultarToken", methods=["POST"])
def consultarToken():
    cedula = request.json['cedula']
    dicc={'codigo':000,'descripcion':'','cedula':'','token':''}
    
    logger.info('-------Inicia Proceso APP------')
    #inicializacion
    codigo=None
    try:
        #conexion
        conn=conexion()
        cur=conn.cursor()
        sql="""select cedula,tokens from tokens where cedula='{0}'""".format(cedula)
        cur.execute(sql)
        valores=cur.fetchone()

        dicc["codigo"]=200
        dicc["descripcion"]="consulta realizada con Exito"
        dicc["cedula"]=valores[0]
        dicc["token"]=valores[1]

        return jsonify(dicc)

    except Exception as e:
        logger.error("Error "+str(e))
        print "Excepción en consulta",str(e)
        dicc["codigo"]=400
        dicc["descripcion"]="no se pudo consultar el tokens "+str(e)+""
        return jsonify(dicc)
           
    finally:
        cur.close()
        conn.close()


@app.route("/consulta", methods=["POST"])
def consulta():
    dicc={'codigo':000,'descripcion':'','factor':'','entrada':''}
    print 'loggggggggggggggggg'
    logger.info('-------Inicia Proceso APP------')
    #inicializacion
    codigo=None
    try:
        #conexion
        conn=conexion()
        cur=conn.cursor()
        
        #consulta filtros
        sql="""select name,cant_entradas from conversion order by create_date desc"""
        cur.execute(sql)
        result=cur.fetchone()
        codigo=result[0]
        entrada=result[1] 

        dicc["codigo"]=200
        dicc["descripcion"]="Exito"
        dicc["factor"]=codigo
        dicc["entrada"]=entrada
        return jsonify(dicc)
        
    except Exception as e:
        logger.error("Error en consulta"+str(e))
        print "Excepción en consulta",str(e) 
        dicc["codigo"]=400
        dicc["descripcion"]="Excepción en consulta",str(e)
        return jsonify(dicc)
           
    finally:
        cur.close()
        conn.close()



@app.route("/consultaUsuario", methods=["POST"])
def consultaUsuario():
    cedula = request.json['cedula']
    dicc={'codigo':000,'descripcion':'','cedula':'','name':'','apellido':'','celular':'','email':''}
    
    logger.info('-------Inicia Proceso APP------')
    #inicializacion
    codigo=None
    try:
        #conexion
        conn=conexion()
        cur=conn.cursor()
        
        #consulta filtros
        sql="""select cedula,display_name,apellido,celular,email from res_partner where cedula='{0}'""".format(cedula)
        print sql
        cur.execute(sql)
        result=cur.fetchone()
	print 'resultado del query consulta usuario',result

        cedula=result[0]
        name=result[1]
        apellido=result[2]
        celular=result[3]
        email=result[4]   

        dicc["codigo"]=200
        dicc["descripcion"]="El usuario existe en la base de datos"
        dicc["cedula"]=cedula
        dicc["name"]=name
        dicc["apellido"]=apellido
        dicc["celular"]=celular
        dicc["email"]=email
        return jsonify(dicc)
        
    except Exception as e:
        logger.error("Error en consulta"+str(e))
        print "Excepción en consulta",str(e)
        dicc["codigo"]=400
        dicc["descripcion"]="El usuario no se encuentra Registrado"
        return jsonify(dicc)
           
    finally:
        cur.close()
        conn.close()

@app.route("/serClave", methods=["POST"])
def sertClave():
    cedula = request.json['cedula']
    clave = request.json['clave']


    dicc={'codigo':000,
          'descripcion':''
          }
          # 'cedula':'',
          # 'name':'',
          # 'apellido':'',
          # 'celular':'',
          # 'email':''}
    
    logger.info('-------Inicia Proceso APP------')
    #inicializacion
    codigo=None
    try:
        #conexion
        conn=conexion()
        cur=conn.cursor()
        
        #consulta filtros
        sql="""select cedula from clavetmp where cedula='{0}'""".format(cedula)
        print sql
        cur.execute(sql)
        result=cur.fetchall()        
        if result==[]:

            print 'no existe celular'
            print '+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++'
            sql="""insert into clavetmp(cedula,clave) values('{0}','{1}')""".format(cedula,clave.encode('UTF-8'))
            print sql
            cur.execute(sql)
            conn.commit()


            dicc={'codigo':000,
                      'descripcion':''
                     }
            dicc["codigo"]=200
            dicc["descripcion"]="clave registrado correctamente"
           

            return jsonify(dicc)

                

        if result!=[]:
            cedula=result[0][0]
            sql="""update clavetmp set clave='{0}' where cedula='{1}'""".format(clave.encode('UTF-8'),cedula)
            print sql
            cur.execute(sql)
            conn.commit()

            
            dicc["codigo"]=200
            dicc["descripcion"]='Actualiza Clavee de la cedula '+cedula+''

            return jsonify(dicc)

       
        
    except Exception as e:
        logger.error("Error en consulta"+str(e))
        print "Excepción en consulta",str(e)
        dicc["codigo"]=400
        dicc["descripcion"]="No se pudo registrar al usuario "+str(e)+""
        return jsonify(dicc)

@app.route("/consultaClave", methods=["POST"])
def consultaClave():
    cedula = request.json['cedula']



    dicc={'codigo':000,
          'descripcion':''
          }
          # 'cedula':'',
          # 'name':'',
          # 'apellido':'',
          # 'celular':'',
          # 'email':''}
    
    logger.info('-------Inicia Proceso APP------')
    #inicializacion
    codigo=None
    try:
        #conexion
        conn=conexion()
        cur=conn.cursor()
        print '------'
        #consulta filtros
        sql="""select clave from clavetmp where cedula='{0}'""".format(cedula)
        print sql
        cur.execute(sql)
        result=cur.fetchall()        
        if result==[]:

  

            dicc={'codigo':000,
                      'descripcion':''
                     }
            dicc["codigo"]=400
            dicc["descripcion"]="El usuario no posee clave"
           

            return jsonify(dicc)

                

        if result!=[]:
            clave=result[0][0]

            dicc2={'codigo':000,
                      'descripcion':'',
                      'clave':''
                     }
            dicc2["codigo"]=200
            dicc2["descripcion"]='Exito'
            dicc2["clave"]=clave

            return jsonify(dicc2)

       
        
    except Exception as e:
        logger.error("Error en consulta"+str(e))
        print "Excepción en consulta",str(e)
        dicc["codigo"]=400
        dicc["descripcion"]="No se pudo registrar al usuario "+str(e)+""
        return jsonify(dicc)         
    finally:
        cur.close()
        conn.close()

@app.route("/insertarUsuario", methods=["POST"])
def insertarUsuario():
    cedula = request.json['cedula']
    nombre = request.json['name']
    apellido = request.json['apellido']
    celular = request.json['celular']
    email = request.json['email']

    dicc={'codigo':000,
          'descripcion':''
          }
          # 'cedula':'',
          # 'name':'',
          # 'apellido':'',
          # 'celular':'',
          # 'email':''}
    
    logger.info('-------Inicia Proceso APP------')
    #inicializacion
    codigo=None
    try:
        #conexion
        conn=conexion()
        cur=conn.cursor()
        print nombre, apellido ,'=========================================' 

        
        #consulta filtros
        sql="""select cedula from res_partner where cedula='{0}'""".format(cedula)
        print sql
        cur.execute(sql)
        result=cur.fetchall()        
        if result==[]:

            print '+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++'
            qupdate="""update res_partner set celular='' where celular='{0}'""".format(celular)
            cur.execute(qupdate)
            sql="""insert into res_partner(cedula,name,display_name,apellido,celular,email,notify_email,invoice_warn,picking_warn,purchase_warn,sale_warn,active)
                values('{0}','{0}','{1}','{2}','{3}','{4}','always','no-message','no-message','no-message','no-message','t')""".format(cedula,nombre.encode('UTF-8'),apellido.encode('UTF-8'),celular,email.encode('UTF-8'))
            print sql
            cur.execute(sql)
            conn.commit()
            queryentrada="""update estado_entrada set cedula='{0}' where celular='{1}' and estado='E'""".format(cedula,celular)
            print queryentrada
            cur.execute(queryentrada)
            conn.commit()

            query= """select max(id) from res_partner""" 
            cur.execute(query)
            result=cur.fetchone()
            partner_id=result[0]
            dicc={'codigo':000,
                      'descripcion':''
                  }
            dicc["codigo"]=200
            dicc["descripcion"]="Usuario registrado correctamente"
            dicc["id"]=partner_id

            return jsonify(dicc)
            print sql

            
                

        if result!=[]:
            cedula=result[0][0]
            dicc["codigo"]=400
            dicc["descripcion"]='ya existe la cedula ingresada '+cedula+''

            return jsonify(dicc)

       
        
    except Exception as e:
        logger.error("Error en consulta"+str(e))
        print "Excepción en consulta",str(e)
        dicc["codigo"]=400
        dicc["descripcion"]="No se pudo registrar al usuario "+str(e)+""
        return jsonify(dicc)
           
    finally:
        cur.close()
        conn.close()

@app.route("/actUsuario", methods=["POST"])
def actUsuario():
    cedula = request.json['cedula']
    nombre = request.json['name']
    apellido = request.json['apellido']
    celular = request.json['celular']
    email = request.json['email']

    dicc={'codigo':200,
          'descripcion':''
          }

    logger.info('-------Inicia Proceso APP------')
    #inicializacion
    try:
        #conexion
        conn=conexion()
        cur=conn.cursor()
        print '--------',nombre
        if len(nombre)!=0:
            sql="""update res_partner set display_name='{0}' where cedula='{1}'""".format(nombre.encode('UTF-8'),cedula)
            print sql
            cur.execute(sql)
            conn.commit()
            dicc["descripcion"]="actualizado correctamente"
        if len(apellido)!=0:
            sql="""update res_partner set apellido='{0}' where cedula='{1}'""".format(apellido.encode('UTF-8'),cedula)
            print sql
            cur.execute(sql)
            conn.commit()
            dicc["descripcion"]="actualizado correctamente"
        if len(celular)!=0:
            sql="""update res_partner set celular='' where celular='{0}' """.format(celular)
            print sql
            cur.execute(sql)
            conn.commit()

            sql2="""update res_partner set celular='{0}' where cedula='{1}' """.format(celular,cedula)
            print sql2
            cur.execute(sql2)
            conn.commit()

	    sql3="""update estado_entrada set celular='{0}' where cedula='{1}' """.format(celular,cedula)
            print sql3
            cur.execute(sql3)
            conn.commit()


            dicc["descripcion"]="actualizado correctamente"      
        if len(email)!=0:
            sql="""update res_partner set email='{0}' where cedula='{1}'""".format(email.encode('UTF-8'),cedula)
            print sql
            cur.execute(sql)
            conn.commit() 
            dicc["descripcion"]="actualizado correctamente"   

        return jsonify(dicc)

    except Exception as e:
        logger.error("Error en consulta"+str(e))
        print "Excepción en consulta",str(e)
        dicc["codigo"]=400
        dicc["descripcion"]="No se pudo actualizar al usuario "+str(e)+""
        return jsonify(dicc)
           
    finally:
        cur.close()
        conn.close()


@app.route("/compra", methods=["POST"])
def compra():
    

    partido = request.json['partido']
    fecha_partido = request.json['fecha_partido']
    hr_partido = request.json['hr_partido']
    cant_tot_entradas = request.json['cant_tot_entradas']
    cedula = request.json['cedula']
    cod_aprob = request.json['cod_aprob']
    dicc={'codigo':'','descripcion':'','id_compra':''}
    logger.info('-------Inicia Proceso APP------')
    try: 
        print "PRUEBA CONEXION"
        conn=conexion()
        cur=conn.cursor()
        result=cur.fetchall 
        query="""select id, cedula from res_partner
                        where cedula=%s"""
        cur.execute(query,(cedula,))
        result=cur.fetchone() 

        if result==None:
            sql= """Insert into res_partner(name,cedula,notify_email,invoice_warn,picking_warn,purchase_warn,sale_warn)
                    values (%s,%s,'none','no-message','no-message','no-message','no-message')"""
            cur.execute(sql,(cedula,cedula))
            conn.commit()
            query="""select id, cedula from res_partner 
                     where cedula=%s"""
            print 
            cur.execute(query,(cedula,)) 
            result=cur.fetchone()
                    #.write({cedula:'result'}) 
            id_clie= result[0]
        else:
            id_clie= result[0] 

        querycomp="""Insert into purchase_order(currency_id,date_order,partner_id,
                                                        picking_type_id ,
                                                        company_id,
                            name,fecha_partido,hr_partido,cant_tot_entradas, state,cod_aprob)
                            values( 1, now() ,%s, 1 , 1 , %s , %s, %s , %s,'draft',%s)""" 
        cur.execute(querycomp,(1,partido,fecha_partido,hr_partido,cant_tot_entradas,cod_aprob))
        conn.commit()
        query= """select max(id) from purchase_order""" 
        cur.execute(query) 
        result=cur.fetchone()
        order_id=result[0]

        print ''
        #===================================================================
        # VENTAS CAB
        #===================================================================
        print '1111111'
        queryvent="""Insert into sale_order(date_order,partner_id, picking_policy ,partner_invoice_id,name,
                     partner_shipping_id,warehouse_id,state,fecha_partido,hr_partido,cant_tot_entradas,partido,compra_id,pricelist_id)
                     values( now() , %s, 'direct' , %s , 'SO' , %s, 1 ,'draft',%s,%s,%s,%s,%s,1)""" 
        cur.execute(queryvent,(id_clie,id_clie,id_clie, fecha_partido,hr_partido,cant_tot_entradas,partido,order_id ))
        conn.commit()
        #===================================================================
        # VENTAS CAB
        #===================================================================
        dicc["codigo"]=200
        dicc["descripcion"]='Exito'
        dicc["id_compra"]=order_id
        return jsonify(dicc)

    except Exception as e:  
        logger.error("Fallo de insert en cabecera compras")
        print "ERROR DE INSERCIÓN CABECERA DE COMPRA"+str(e)
        dicc["codigo"]=400
        dicc["descripcion"]="ERROR DE INSERCIÓN CABECERA DE COMPRA"+str(e)
        return jsonify(dicc)

    finally:
        cur.close()
        conn.close()
@app.route("/detcompra", methods=["POST"])
def detcompra():
    id_compra = request.json['id_compra']
    num_entrada = request.json['num_entrada']
    localidad = request.json['localidad']
    partido = request.json['partido']
    hr_partido = request.json['hr_partido']
    val_dolares = request.json['val_dolares']
    fecha_partido =request.json['fecha_partido']
    entrada = request.json['entrada']
    id_evento= request.json['evento_id']
    logger.info('-------Inicia Proceso APP------')
    print fecha_partido
    dicc={'codigo':'000','descripcion':''}
    try:
        print "DETALLE COMPRA/VENTA"

        conn=conexion() 
        cur=conn.cursor()
        #result=cur.fetchall
        
        #ENTRADA
        queryFactor="""select max(name) from conversion """
        cur.execute(queryFactor)
        result=cur.fetchone()
        factor=result[0]
        dolar=round(val_dolares,2)
        Millas= val_dolares * factor
        a = decimal.Decimal(Millas)
        MillasRound=round(a,0)
            
        querydet="""Insert into purchase_order_line(date_planned,product_uom,price_unit,product_qty,product_id,order_id,num_entrada,localidad,name,fecha_partido,hr_partido,val_dolares,val_millas)
                    values('2017-12-20',1,2,1,1,%s,%s,%s,%s,%s,%s,%s,%s)""" 

        cur.execute(querydet,(id_compra,num_entrada,localidad,partido,fecha_partido,hr_partido,dolar, MillasRound)) 
        conn.commit()


        print '************************'


        #===================================================================
        # DETALLE DE ENTRADAS VENTAS
        #===================================================================
        print 'bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb'
        query= """select id from sale_order where compra_id={0}""".format(id_compra) 
        cur.execute(query)
        result=cur.fetchone()
        order_id=result[0]
        print order_id



        print 'ccccccccccccccccccccccccccccccc',order_id,factor, Millas, MillasRound
        queryvetdet = """ Insert into sale_order_line(product_uom,price_unit,product_uom_qty,product_id,order_id,customer_lead,num_entrada,localidad,name,fecha_partido,hr_partido,val_dolares,val_millas)
                          values(1,%s,1,(select id from product_template where name = 'Entradas'),%s,0,%s,%s,%s,%s,%s,%s,%s)"""
            
        cur.execute(queryvetdet,(val_dolares ,order_id,num_entrada,localidad,partido,fecha_partido,hr_partido,dolar,MillasRound))
        conn.commit()


        querypartner="""select partner_id from sale_order where id={0}""".format(order_id)
        print querypartner
        cur.execute(querypartner)
        result=cur.fetchone()
        cliente_id=result[0]
        print '************************',cliente_id
        querypartnercc="""select b.cedula,b.celular from sale_order a
             join res_partner as b on a.partner_id=b.id and a.id={0} limit 1""".format(order_id)
        print querypartnercc
        cur.execute(querypartnercc)
        result=cur.fetchone()
        cliente_cedula=result[0]
        cliente_celular=result[1]

        queryid="""select max(id) from purchase_order_line where order_id={0}""".format(id_compra)
        print queryid
        cur.execute(queryid)
        result=cur.fetchone()
        detalle_id=result[0]

        print '************************'
        queryestado="""insert into estado_entrada(cedula,celular,emisor,estado,fecha,entrada,compra_id,evento_id) values     
             ('{0}','{1}','','A',now(),'{2}',{3},{4})""".format(cliente_cedula,cliente_celular,entrada.encode('UTF-8'),detalle_id,id_evento)
        print queryestado
        cur.execute(queryestado)
        conn.commit()
        ##self.cal_valmillas()
        
        
        #===================================================================
        # DETALLE DE ENTRADAS VENTAS
        #===================================================================
        dicc["codigo"]=200
        dicc["descripcion"]="REGISTRO OK"
        cur.execute("""update sale_order set name='ventas'""")
        conn.commit()
        return jsonify(dicc)

    except Exception as e:
        logger.error("Fallo en insert detalle de compra")
        print "ERROR DE INSERCION DETALLE DE COMPRA"+str(e)
        dicc["codigo"]=400
        dicc["descripcion"]="ERROR DE INSERCION DETALLE DE COMPRA " +str(e)
        return jsonify(dicc)
 
    finally: 
        queryTotal="update sale_order set amount_total=(select sum(val_dolares) from sale_order_line where order_id={0}) where id={0}".format(order_id)
        cur.execute(queryTotal)
        conn.commit()
        print 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa',queryTotal
        cur.close()
        conn.close()


@app.route("/consultaEntrada", methods=["POST"])
def consultaEntrada():
    cedula = request.json['cedula']
    dicc={'codigo':000,'descripcion':'','detalle':''}

    dicc2={'idcompra':'','cedula':'','localidad':''}
    dicc3={}
    logger.info('-------Inicia Proceso APP------')
    #inicializacion
    codigo=None
    try:
        #conexion
        conn=conexion()
        cur=conn.cursor()
        detalle_array = []
        print 'Pasa cnxion'
        #consulta filtros
        sql=""" select b.cedula,a.order_id,a.num_entrada,a.localidad,a.name,a.fecha_partido as fp,a.hr_partido,a.val_dolares,
     b.entrada,b.estado,b.emisor,b.celular,a.val_millas,to_char(b.fecha,'YYYY-MM-DD HH24:MI:SS'),b.evento_id,b.beneficiario
 from purchase_order_line a, estado_entrada b where a.id=b.compra_id and b.cedula='{0}'""".format(cedula)
        print sql
        cur.execute(sql)
        result=cur.fetchall()
        if result==[]:
            dicc["codigo"]=200
            dicc["descripcion"]="El usuario no Registra Compras de Entradas"
            dicc["detalle"]=None  
            return jsonify(dicc)
        
        x=0
        del detalle_array[:]
        for l in result:
            x=x+1
         
            cedula=l[0]
            compraId=l[1]
            num_entrada=l[2]
            localidad=l[3]
            partido=l[4]
            fecha_partido=l[5]
            hora_partido=l[6]
            valor_dolares=l[7]
            entradaId=l[8]
            estado=l[9] 
            emisor=l[10]
            celular=l[11]
            millas=l[12]
            fecha=l[13]
            evento_id=l[14]
            beneficiario=l[15]



            employee_data ={'idcompra':compraId,
                            'cedula':cedula,
                            'numero_entrada':num_entrada,
                            'localidad':localidad,
                            'encuentro':partido,
                            'fecha':fecha_partido,
                            'hora':hora_partido,
                            'costo':valor_dolares,
                            'entradaId':entradaId,
                            'estado':estado,
                            'emisor':emisor,
                            'celular':celular,
                            'millas':millas,
                            'fecha_compra':fecha,
                            'evento_id':evento_id,
                            'beneficiario':beneficiario
                            }

            detalle_array.append(employee_data)
           # emisor=result[[0][0]  
            print x
        #for i in detalle_array:
        dicc["detalle"]=(detalle_array)
        dicc["codigo"]=200
        dicc["descripcion"]="exito"
        
        

        print cedula,compraId,num_entrada,localidad,partido,fecha_partido,hora_partido,hora_partido,valor_dolares,entradaId,estado,emisor
        return jsonify(dicc)
        
    except Exception as e:
        logger.error("Error en consulta"+str(e))
        print "Excepción en consulta",str(e) 
        dicc["codigo"]=400
        dicc["descripcion"]="error"+str(e)+""
        return jsonify(dicc)
           
    finally:
        cur.close()
        conn.close()

@app.route("/traspasoEntrada", methods=["POST"])
def traspasoEntrada():
    emisor = request.json['emisor']
    celular = request.json['celular']
    entrada = request.json['entrada']
    dicc={'codigo':000,'descripcion':''}
    
    logger.info('-------Inicia Proceso APP------')
    #inicializacion
    codigo=None
    try:
        #conexion
        conn=conexion()
        cur=conn.cursor()

        querytransf="""select count(entrada) from estado_entrada where entrada='{0}' and estado='T'""".format(entrada)
        print querytransf
        cur.execute(querytransf)
        var = cur.fetchall();
        print int(var[0][0])

        queryvalort="""select max(max_trans) from conversion"""
        print queryvalort
        cur.execute(queryvalort)
        varmax = cur.fetchall();


        if var[0][0]<varmax[0][0]:
            
            queryvetdet = """update estado_entrada set estado='F',beneficiario='{2}' where cedula='{0}' and entrada='{1}' and estado='A'""".format(emisor,entrada,celular)  
            print queryvetdet          
            cur.execute(queryvetdet)
            conn.commit()

            queryusuario="""select cedula from res_partner where celular='{0}' """.format(celular)
            print queryusuario         
            cur.execute(queryusuario)
            var2 = cur.fetchall();

            if var2!=[]:

                sql="""select compra_id from estado_entrada where cedula='{0}' and estado='F' and entrada='{1}'""".format(emisor,entrada)
                print sql
                cur.execute(sql)
                result=cur.fetchone()

                compra=result[0]

                querievento=""" select evento_id from estado_entrada where cedula='{0}' and entrada='{1}'""".format(emisor,entrada)
                cur.execute(querievento)
                resultado=cur.fetchone()

                evento_id=resultado[0]


                queryestado="""insert into estado_entrada(cedula,celular,emisor,estado,fecha,entrada,compra_id,evento_id) values     
                ('{0}','{1}','{2}','E',now(),'{3}','{4}','{5}')""".format(var2[0][0],celular,emisor,entrada.encode('UTF-8'),compra,evento_id)
                print queryestado
                cur.execute(queryestado)
                conn.commit()
            if var2==[]:

                sql="""select compra_id from estado_entrada where cedula='{0}' and estado='F' and entrada='{1}' """.format(emisor,entrada)
                print sql
                cur.execute(sql)
                result=cur.fetchone()

                compra=result[0]

                querievento=""" select evento_id from estado_entrada where cedula='{0}' and entrada='{1}'""".format(emisor,entrada)
                cur.execute(querievento)
                resultado=cur.fetchone()

                evento_id=resultado[0]

                queryestado="""insert into estado_entrada(cedula,celular,emisor,estado,fecha,entrada,compra_id,evento_id) values     
                ('','{0}','{1}','E',now(),'{2}','{3}','{4}')""".format(celular,emisor,entrada,compra,evento_id)
                print queryestado
                cur.execute(queryestado)
                conn.commit()



            dicc["codigo"]=200
            dicc["descripcion"]="acaba de enviar una entrada por confirmar al numero "+celular+""
            return jsonify(dicc)
        else:
            dicc["codigo"]=500
            dicc["descripcion"]="ha execido el numero maximo de transferencia "
            return jsonify(dicc)

    except Exception as e:
        logger.error("Error en consulta"+str(e))
        print "Excepción en consulta",str(e) 
        dicc["codigo"]=400
        dicc["descripcion"]="no se pudo transferir la entrada "+str(e)+""
        return jsonify(dicc)
           
    finally:
        cur.close()
        conn.close()

@app.route("/cambiarEstado", methods=["POST"])
def cambiarEstado():
    celular = request.json['cedula']
    entrada = request.json['entrada']
    dicc={'codigo':000,'descripcion':''}
    
    logger.info('-------Inicia Proceso APP------')
    #inicializacion
    codigo=None
    try:
        #conexion
        conn=conexion()
        cur=conn.cursor() 

        querypre="""select estado from estado_entrada where estado='A' and emisor='{0}' and entrada='{1}'""".format(celular,entrada)
        print querypre
        cur.execute(querypre)
        var2 = cur.fetchall();
        if var2!=[]:
            dicc["codigo"]=400
            dicc["descripcion"]="usted ya acepto esta entrada"
            return jsonify(dicc)

        queryvetdet = """update estado_entrada set estado='A' where emisor='{0}' and entrada='{1}' and estado='E'""".format(celular,entrada)  
        print queryvetdet          
        cur.execute(queryvetdet)
        conn.commit()

        queryemisor="""update estado_entrada set estado='T' where estado='F' and entrada='{0}' and cedula='{1}' """.format(entrada,celular)
        print queryemisor         
        cur.execute(queryemisor)
        conn.commit()

        dicc["codigo"]=200
        dicc["descripcion"]="acaba de aceptar una entrada"
        return jsonify(dicc)


    except Exception as e:
        logger.error("Error en consulta"+str(e))
        print "Excepción en consulta",str(e) 
        dicc["codigo"]=400
        dicc["descripcion"]="no se pudo cambiar el estado "+str(e)+""
        return jsonify(dicc)
           
    finally:
        cur.close()
        conn.close()

@app.route("/cambiarEstadoAnterior", methods=["POST"])
def cambiarEstadoAnterior():
    cedula = request.json['cedula']
    entrada = request.json['entrada']
    dicc={'codigo':000,'descripcion':''}
    
    logger.info('-------Inicia Proceso APP------')
    #inicializacion
    codigo=None
    try:
        #conexion
        conn=conexion()
        cur=conn.cursor()

        queryestado="""select estado from estado_entrada where entrada='{0}' and cedula='{1}' and estado='F'""".format(entrada,cedula)
        print queryestado         
        cur.execute(queryestado)
        resquest=cur.fetchone();
        estado=resquest[0]
        
        if estado=='F':

            queryvetdet = """update estado_entrada set estado='C' where emisor='{0}' and entrada='{1}' and estado='E'""".format(cedula,entrada)  
            print queryvetdet          
            cur.execute(queryvetdet)
            conn.commit()

            queryemisor="""update estado_entrada set estado='A' where estado='F' and entrada='{0}' and cedula='{1}' """.format(entrada,cedula)
            print queryemisor         
            cur.execute(queryemisor)
            conn.commit()

            dicc["codigo"]=200
            dicc["descripcion"]="acaba de cancelar el transpaso"
            return jsonify(dicc)



    except Exception as e:
        logger.error("Error en consulta"+str(e))
        print "Excepción en consulta",str(e) 
        dicc["codigo"]=400
        dicc["descripcion"]="no se pudo cancelar el transpaso "+str(e)+""
        return jsonify(dicc)
           
    finally:
        cur.close()
        conn.close()




@app.route("/consultarEntradaUsuario", methods=["POST"])
def consultarEntradaUsuario():
    celular = request.json['celular']


    dicc={'codigo':000,'descripcion':''}
    
    logger.info('-------Inicia Proceso APP------')
    #inicializacion
    codigo=None
    try:
        #conexion
        conn=conexion()
        cur=conn.cursor()

        sql="""select * from estado_entrada where celular='{0}' and estado='E'""".format(celular)
        print sql
        cur.execute(sql)
        result=cur.fetchall()

        if result!=[]:
            dicc["codigo"]=200
            dicc["descripcion"]="el usuario con numero de celular "+celular+" se encuentra en la tabla de entrada"
            return jsonify(dicc)


        if result==[]:
            dicc["codigo"]=400
            dicc["descripcion"]="el usuario no se encuentra en la tabla de entrada o posee un estado diferente de E"
            return jsonify(dicc)


    except Exception as e:
        logger.error("Error en consulta"+str(e))
        print "Excepción en consulta",str(e) 
        dicc["codigo"]=400
        dicc["descripcion"]="error "+str(e)+""
        return jsonify(dicc)
           
           
    finally:
        cur.close()
        conn.close()

if __name__ == '__main__':
    app.run(host='0.0.0.0',debug=True,port=8080)
