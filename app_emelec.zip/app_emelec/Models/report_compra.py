# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

#
# Please note that these reports are not multi-currency !!!
#

from odoo import api, fields, models,tools
class ReportesCompra(models.Model):
    _name = "report.compra"
    _auto = False
   # _order = 'date_order desc, price_total desc'
    
    partner_id = fields.Many2one('res.partner', 'Proveedor')
    date_order = fields.Datetime('Fecha Compra', readonly=True, help="Date on which this document has been created", oldname='date')
    fecha_partido =fields.Char('Fecha Partido')
    localidad=fields.Char('Localidad')
    cant_entradas=fields.Float('Cantidad Entradas')
    val_dolares=fields.Float('Valor Entradas')
    ####val_millas=fields.Many2one('sale.order.line','Cantidad Millas')
    cod_aprob=fields.Char('Numero Canje/Aprobacion')

    # insp_asig = fields.Many2one('res.users',string="Inspector:")
    # num_reporte = fields.Char(string="No. Reporte", size=4)
    # name =fields.Char(string="N° de orden")
    # puntuacion_total=fields.Integer('Puntaje total')
    # name_comp = fields.Many2one('res.partner', string='Empresa Aseguradora:', readonly=True)
    # state = fields.Selection([
    #       ('pendiente', 'PENDIENTE'),
    #       ('iniciado', 'INICIADO'),
    #       ('inf_entreg', 'REALIZADO'), 
    #       ('cancelado', 'CANCELADO'), 
    #       ], string='Estado', readonly=True)

    # cedula
    # name
    # fecha_partido
    # hr_partido
    # cant_tot_entradas
    # cod_aprob

   
    #=========================VISTA==================================================


    @api.model_cr
    def init(self):
        tools.drop_view_if_exists(self._cr, 'report_compra')
        self._cr.execute(""" create view report_compra as (
                        
          select 
           so.partner_id,
           so.date_order,
           so.fecha_partido,
           sol.localidad, 
                      so.cant_tot_entradas::double precision as cant_entradas,
           sol.val_dolares,
           so.cod_aprob,
           so.id
           from 
           purchase_order so , 
           purchase_order_line sol  
           where so.id = sol.order_id )
       
                              """)
