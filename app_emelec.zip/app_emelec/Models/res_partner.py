# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
from odoo import fields, models, api, _
from datetime import timedelta
from odoo.exceptions import ValidationError, except_orm

class Partner(models.Model):
 
    _description = "Partner" 
    _inherit = 'res.partner'
    _order = "name" 

    cedula = fields.Char(string='Cedula')
    active=fields.Boolean(string='Activo',default=True)
    company_type = fields.Selection([('person', 'Cliente'), ('company', 'Proveedor')],String='Company Type',compute='_compute_company_type', readonly=False)


