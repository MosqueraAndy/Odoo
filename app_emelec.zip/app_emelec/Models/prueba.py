import oerplib

#oerp = oerplib.OERP(server='10.35.2.227', protocol='xmlrpc', port=8069)
#user = oerp.login(user='odoo', passwd='admin')

#user = oerp.login(user='admin', passwd='iguanadigital', database='IGUDISA')

oerp = oerplib.OERP(server='172.17.0.4', protocol='xmlrpc', port=8070)
#user = oerp.login(user='odoo', passwd='admin')
user = oerp.login(user='odoo', passwd='admin', database='calendar')

print(user.name)