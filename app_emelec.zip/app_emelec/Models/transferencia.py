## -*- coding: utf-8 -*-

from odoo import fields, models

class Transferencia(models.Model):

	_name = 'transferir'
	_description= "Número máximo de transferencia"

	name = fields.Integer('Número máximo de transferencia', required=True) 
 	estado = fields.Boolean('Estado',default=True)
