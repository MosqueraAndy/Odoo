# -*- coding: utf-8 -*-

{
    'name' : 'Modulo App Emelec ',
    'version' : '2.0',
    'depends' :[ 'base'  ,'purchase','stock'],
    'author' : 'Righttek',
    'description' : 'Backend Emelec',
    'website' : 'http://www.righttek.com',
    'category' : 'Aplicacion',
  
    'data' : [
                'Views/menu_view.xml',
                #'Views/transferencia_view.xml',
                'Views/estado_entrada_view.xml',
                #'Views/partner_view.xml',
                'Views/email_config_view.xml',
                #'Views/consumir_service_view.xml',
                'Views/clientes_view.xml',
                #'Views/localidades_view.xml',
                #'Views/partido_view.xml',
                #'Views/val_millas_view.xml',
                #'Views/val_dolares_view.xml',
                #'Views/entradas_view.xml',
                'Views/conversion_view.xml',    
                'Views/purchase_views.xml',
                'Views/ventas_view.xml', 
                'Views/report_compra_view.xml',
                'Views/report_venta_view.xml',
                'wizard/report_ventas_.xml',
                'wizard/report_entrada_view.xml'


            ],
#    'active': False,
    'installable': True,
    'auto_install':False,
}


