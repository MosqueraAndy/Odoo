# -*- coding: utf-8 -*-
from itertools import groupby
import xml.etree.ElementTree as ET
from odoo import api, fields, models, _
from odoo.exceptions import UserError
from odoo.tools import float_is_zero, float_compare, DEFAULT_SERVER_DATETIME_FORMAT
from odoo.tools.misc import formatLang 
from odoo.fields import Integer
import odoo.addons.decimal_precision as dp
import datetime
import time
from odoo.exceptions import ValidationError, except_orm
from odoo.exceptions import UserError
from create_excel_entrada import *
from StringIO import StringIO
import base64, time
import commands
import os
from odoo import api, fields, models


class reporte_xls_entrada(models.Model):
    _name = "report.estado.entrada"
    #_inherit = 'sale.order'
    _description = "Reporte de Entradas"
    name=fields.Char(String='Name')
    numero_entrada=fields.Char(String='Número Entrada')
    cedula=fields.Char(String='Cédula')
    celular=fields.Char(String='Celular')
    fecha_desde=fields.Date(String='Fecha desde')
    fecha_hasta=fields.Date(String='Fecha hasta')    
    xls_filename = fields.Char('Nombre Archivo excel')
    archivo_xls = fields.Binary('Archivo excel')

    @api.multi    
    def generate_file(self):
    	fp = StringIO()

    	workbook = self.crear_excel()
    	workbook.save(fp)

    	fecha = datetime.datetime.strftime(datetime.datetime.now(), '%Y-%m-%d %H%M%S')

    	filename = 'Reporte de Entradas'+'.xlsx'
    	return self.write( {
    		'xls_filename': filename,
    		'archivo_xls': base64.b64encode(fp.getvalue())
    		})

    def crear_excel(self):
        wb = crear_wb_entrada()
        self.crear_reportEntrada(wb)
        return wb 

    def crear_reportEntrada(self, wb):
        sheet_hautovehiculo = crea_hoja_entrada(wb, unicodeText_entrada(u'Reportes Entrada'), 0)
        sheet_view = openpyxl.worksheet.SheetView()
        sheet_view.zoomScale = "65"
        sheet_view.zoomScaleNormal = "65"
        sheet_hautovehiculo.sheet_view = sheet_view
        sheet_hautovehiculo.zoomScale = "65"

        fechaActual= (time.strftime("%Y-%m-%d"))
        
        print 'fecha actual',fechaActual
        print 'fechaaaaaa',self.fecha_desde

        if self.cedula !=False and self.numero_entrada==False and self.celular==False:
            print 'se seleccion el reporte con solo cedula y fechas'
            print 'cedula', self.cedula

            #fecha_desde=str(self.fecha_desde).split('-')[2]+"-"+str(self.fecha_desde).split('-')[1]+"-"+str(self.fecha_desde).split('-')[0]
            #fecha_hasta=str(self.fecha_hasta).split('-')[2]+"-"+str(self.fecha_hasta).split('-')[1]+"-"+str(self.fecha_hasta).split('-')[0]
            #print fecha_desde,fecha_hasta
            query= """select b.cedula,a.num_entrada,to_char(b.fecha,'YYYY-MM-DD HH24:MI:SS')  as data_order_ ,a.name,a.localidad,b.estado,b.beneficiario
            from purchase_order_line a, estado_entrada b where a.id=b.compra_id and b.cedula='"""+self.cedula+"""' and b.fecha>='"""+self.fecha_desde+' 00:00:00'+"""' 
            and b.fecha<='"""+self.fecha_hasta+' 23:59:59'+"""' order by b.fecha asc"""

            print 'f==================',query

     
            self.env.cr.execute(query)
            item_acc = self.env.cr.dictfetchall()
            
            self.name="Reporte de Entradas Generado"

            crear_reportEntrada(sheet_hautovehiculo,item_acc,self.fecha_desde,self.fecha_hasta)
        if self.cedula ==False and self.numero_entrada==False and self.celular==False and self.fecha_desde ==False and self.fecha_hasta==False:
            print 'cedula', self.cedula
            fecha_desde="No definida"
            fecha_hasta="No definida"
            #fecha_desde=str(self.fecha_desde).split('-')[2]+"-"+str(self.fecha_desde).split('-')[1]+"-"+str(self.fecha_desde).split('-')[0]
            #fecha_hasta=str(self.fecha_hasta).split('-')[2]+"-"+str(self.fecha_hasta).split('-')[1]+"-"+str(self.fecha_hasta).split('-')[0]
            #print fecha_desde,fecha_hasta
            query= """select b.cedula,a.num_entrada,to_char(b.fecha,'YYYY-MM-DD HH24:misc:SS')  as data_order_ ,a.name,a.localidad,b.estado,b.beneficiario
            from purchase_order_line a, estado_entrada b where a.id=b.compra_id order by b.fecha asc"""

            print 'f==================',query

     
            self.env.cr.execute(query)
            item_acc = self.env.cr.dictfetchall()
            
            self.name="Reporte de Entradas Generado"

            crear_reportEntrada(sheet_hautovehiculo,item_acc,fecha_desde,fecha_hasta)

        if self.cedula ==False and self.numero_entrada!=False and self.celular==False:
            print 'se selecciono un reporte con número de entrada y fechas de validacion'
            print 'cedula', self.cedula

            #fecha_desde=str(self.fecha_desde).split('-')[2]+"-"+str(self.fecha_desde).split('-')[1]+"-"+str(self.fecha_desde).split('-')[0]
            #fecha_hasta=str(self.fecha_hasta).split('-')[2]+"-"+str(self.fecha_hasta).split('-')[1]+"-"+str(self.fecha_hasta).split('-')[0]
            #print fecha_desde,fecha_hasta
            query= """select b.cedula,a.num_entrada,to_char(b.fecha,'YYYY-MM-DD HH24:MI:SS')  as data_order_ ,a.name,a.localidad,b.estado,b.beneficiario
            from purchase_order_line a, estado_entrada b where a.id=b.compra_id and a.num_entrada='"""+self.numero_entrada+"""' and b.fecha>='"""+self.fecha_desde+' 00:00:00'+"""' 
            and b.fecha<='"""+self.fecha_hasta+' 23:59:59'+"""' order by b.fecha asc"""

            print 'f==================',query

     
            self.env.cr.execute(query)
            item_acc = self.env.cr.dictfetchall()
            
            self.name="Reporte de Entradas Generado"

            crear_reportEntrada(sheet_hautovehiculo,item_acc,self.fecha_desde,self.fecha_hasta)


        if self.cedula ==False and self.numero_entrada==False and self.celular==False and self.fecha_desde!=False and self.fecha_hasta!=False:
            print 'solo se seleciono las fechas de validación'
            print 'cedula', self.cedula

            #fecha_desde=str(self.fecha_desde).split('-')[2]+"-"+str(self.fecha_desde).split('-')[1]+"-"+str(self.fecha_desde).split('-')[0]
            #fecha_hasta=str(self.fecha_hasta).split('-')[2]+"-"+str(self.fecha_hasta).split('-')[1]+"-"+str(self.fecha_hasta).split('-')[0]
            #print fecha_desde,fecha_hasta
            query= """select b.cedula,a.num_entrada,to_char(b.fecha,'YYYY-MM-DD HH24:MI:SS')  as data_order_ ,a.name,a.localidad,b.estado,b.beneficiario
            from purchase_order_line a, estado_entrada b where a.id=b.compra_id and b.fecha>='"""+self.fecha_desde+' 00:00:00'+"""' 
            and b.fecha<='"""+self.fecha_hasta+' 23:59:59'+"""' order by b.fecha asc"""

            print 'f==================',query

     
            self.env.cr.execute(query)
            item_acc = self.env.cr.dictfetchall()
            
            self.name="Reporte de Entradas Generado"

            crear_reportEntrada(sheet_hautovehiculo,item_acc,self.fecha_desde,self.fecha_hasta)

        if self.cedula !=False and self.numero_entrada!=False and self.celular==False:
            print 'se selecciono el reporte con cedula, numero de entrada y fechas de validación'
            print 'cedula', self.cedula

            #fecha_desde=str(self.fecha_desde).split('-')[2]+"-"+str(self.fecha_desde).split('-')[1]+"-"+str(self.fecha_desde).split('-')[0]
            #fecha_hasta=str(self.fecha_hasta).split('-')[2]+"-"+str(self.fecha_hasta).split('-')[1]+"-"+str(self.fecha_hasta).split('-')[0]
            #print fecha_desde,fecha_hasta
            query= """select b.cedula,a.num_entrada,to_char(b.fecha,'YYYY-MM-DD HH24:misc:SS')  as data_order_ ,a.name,a.localidad,b.estado,b.beneficiario
            from purchase_order_line a, estado_entrada b where a.id=b.compra_id and a.num_entrada='"""+self.numero_entrada+"""' 
            and b.cedula='"""+self.cedula+"""'
            and b.fecha>='"""+self.fecha_desde+' 00:00:00'+"""' 
            and b.fecha<='"""+self.fecha_hasta+' 23:59:59'+"""' order by b.fecha asc"""

            print 'f==================',query

     
            self.env.cr.execute(query)
            item_acc = self.env.cr.dictfetchall()
            
            self.name="Reporte de Entradas Generado"

            crear_reportEntrada(sheet_hautovehiculo,item_acc,self.fecha_desde,self.fecha_hasta)

        if self.celular!=False and self.cedula==False and self.numero_entrada==False and self.fecha_desde!=False and self.fecha_hasta!=False:
            print 'se selecciono un reporte con número de celular y fechas de validacion'
            print 'cedula', self.cedula

            #fecha_desde=str(self.fecha_desde).split('-')[2]+"-"+str(self.fecha_desde).split('-')[1]+"-"+str(self.fecha_desde).split('-')[0]
            #fecha_hasta=str(self.fecha_hasta).split('-')[2]+"-"+str(self.fecha_hasta).split('-')[1]+"-"+str(self.fecha_hasta).split('-')[0]
            #print fecha_desde,fecha_hasta
            query= """select b.cedula,a.num_entrada,to_char(b.fecha,'YYYY-MM-DD HH24:MI:SS')  as data_order_ ,a.name,a.localidad,b.estado,b.beneficiario
            from purchase_order_line a, estado_entrada b where a.id=b.compra_id and b.celular='"""+self.celular+"""' and b.fecha>='"""+self.fecha_desde+' 00:00:00'+"""' 
            and b.fecha<='"""+self.fecha_hasta+' 23:59:59'+"""' order by b.fecha asc"""

            print 'f==================',query

            self.env.cr.execute(query)
            item_acc = self.env.cr.dictfetchall()
            
            self.name="Reporte de Entradas Generado"

            crear_reportEntrada(sheet_hautovehiculo,item_acc,self.fecha_desde,self.fecha_hasta)


        if self.celular!=False and self.cedula!=False and self.numero_entrada==False and self.fecha_desde!=False and self.fecha_hasta!=False:
            print 'se selecciono un reporte con número de celular, cedula y fechas de validacion'
            print 'cedula', self.cedula

            #fecha_desde=str(self.fecha_desde).split('-')[2]+"-"+str(self.fecha_desde).split('-')[1]+"-"+str(self.fecha_desde).split('-')[0]
            #fecha_hasta=str(self.fecha_hasta).split('-')[2]+"-"+str(self.fecha_hasta).split('-')[1]+"-"+str(self.fecha_hasta).split('-')[0]
            #print fecha_desde,fecha_hasta
            query= """select b.cedula,a.num_entrada,to_char(b.fecha,'YYYY-MM-DD HH24:MI:SS')  as data_order_ ,a.name,a.localidad,b.estado,b.beneficiario
            from purchase_order_line a, estado_entrada b where a.id=b.compra_id and b.celular='"""+self.celular+"""' 
            and b.cedula='"""+self.cedula+"""'and b.fecha>='"""+self.fecha_desde+' 00:00:00'+"""' 
            and b.fecha<='"""+self.fecha_hasta+' 23:59:59'+"""' order by b.fecha asc"""

            print 'f==================',query

            self.env.cr.execute(query)
            item_acc = self.env.cr.dictfetchall()
            
            self.name="Reporte de Entradas Generado"

            crear_reportEntrada(sheet_hautovehiculo,item_acc,self.fecha_desde,self.fecha_hasta)

        if self.celular!=False and self.cedula!=False and self.numero_entrada!=False and self.fecha_desde!=False and self.fecha_hasta!=False:
            print 'se selecciono un reporte con número de celular, cedula, número de entrada y fechas de validacion'
            print 'cedula', self.cedula

            #fecha_desde=str(self.fecha_desde).split('-')[2]+"-"+str(self.fecha_desde).split('-')[1]+"-"+str(self.fecha_desde).split('-')[0]
            #fecha_hasta=str(self.fecha_hasta).split('-')[2]+"-"+str(self.fecha_hasta).split('-')[1]+"-"+str(self.fecha_hasta).split('-')[0]
            #print fecha_desde,fecha_hasta
            query= """select b.cedula,a.num_entrada,to_char(b.fecha,'YYYY-MM-DD HH24:MI:SS')  as data_order_ ,a.name,a.localidad,b.estado,b.beneficiario
            from purchase_order_line a, estado_entrada b where a.id=b.compra_id and b.celular='"""+self.celular+"""' 
            and b.cedula='"""+self.cedula+"""' and a.num_entrada='"""+self.numero_entrada+"""' and b.fecha>='"""+self.fecha_desde+' 00:00:00'+"""' 
            and b.fecha<='"""+self.fecha_hasta+' 23:59:59'+"""' order by b.fecha asc"""

            print 'f==================',query

            self.env.cr.execute(query)
            item_acc = self.env.cr.dictfetchall()
            
            self.name="Reporte de Entradas Generado"

            crear_reportEntrada(sheet_hautovehiculo,item_acc,self.fecha_desde,self.fecha_hasta)

        if self.celular!=False and self.cedula==False and self.numero_entrada!=False and self.fecha_desde!=False and self.fecha_hasta!=False:
            print 'se selecciono un reporte con número de celular, número de entrada y fechas de validacion'
            print 'cedula', self.cedula

            #fecha_desde=str(self.fecha_desde).split('-')[2]+"-"+str(self.fecha_desde).split('-')[1]+"-"+str(self.fecha_desde).split('-')[0]
            #fecha_hasta=str(self.fecha_hasta).split('-')[2]+"-"+str(self.fecha_hasta).split('-')[1]+"-"+str(self.fecha_hasta).split('-')[0]
            #print fecha_desde,fecha_hasta
            query= """select b.cedula,a.num_entrada,to_char(b.fecha,'YYYY-MM-DD HH24:MI:SS')  as data_order_ ,a.name,a.localidad,b.estado,b.beneficiario
            from purchase_order_line a, estado_entrada b where a.id=b.compra_id and b.celular='"""+self.celular+"""' 
            and a.num_entrada='"""+self.numero_entrada+"""' and b.fecha>='"""+self.fecha_desde+' 00:00:00'+"""' 
            and b.fecha<='"""+self.fecha_hasta+' 23:59:59'+"""' order by b.fecha asc"""

            print 'f==================',query

            self.env.cr.execute(query)
            item_acc = self.env.cr.dictfetchall()
            
            self.name="Reporte de Entradas Generado"

            crear_reportEntrada(sheet_hautovehiculo,item_acc,self.fecha_desde,self.fecha_hasta)


        if self.cedula==False and self.numero_entrada==False and self.celular==False and self.fecha_desde!=False and self.fecha_hasta==True:

            raise UserError(_('Debe de poner ambas fechas'))

        if self.cedula==False and self.numero_entrada==False and self.celular==False and self.fecha_hasta!=False and self.fecha_desde==True:

            raise UserError(_('Debe de poner ambas fechas'))

        


