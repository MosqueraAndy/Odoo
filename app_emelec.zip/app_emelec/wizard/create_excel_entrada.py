# -*- coding: utf-8 -*-
from openpyxl import Workbook
import openpyxl.worksheet
#import tkFileDialog
import unicodedata
#from Tkinter import Tk
from openpyxl.styles import PatternFill, Border, Side, Alignment, Protection, Font
from openpyxl.styles.borders import Border, Side
from openpyxl.drawing.image import Image
import time
import locale
from StringIO import StringIO
import base64, time
import commands
import os

#import Tkinter, tkFileDialog 
# import threading
global root
def crear_wb_entrada():
    wb = openpyxl.Workbook(encoding="UTF-8")
    return wb


def unicodeText_entrada(text):
    try:
        text = unicode(text, 'utf-8')
    except TypeError:
        return text

def crea_hoja_entrada(wb, title, flag):
    # sheet = wb.get_active_sheet()
    if(flag == 0):
        sheet = wb.active
        sheet.sheet_properties.pageSetUpPr.fitToPage = True

        #sheet.page_setup.orientation = sheet.ORIENTATION_PORTRAIT
        sheet.page_setup.fitToWidht = False
    if(flag == 1):
        sheet = wb.create_sheet()
        sheet.sheet_properties.pageSetUpPr.fitToPage = True

        #sheet.page_setup.orientation = sheet.ORIENTATION_PORTRAIT
        sheet.page_setup.fitToWidht = False
    sheet.title = title
    return sheet

# Ajustar tamanios de celdas
def ajustar_hoja_entrada(sheet, flag, celda, value):
    if (flag == 0):
        sheet.column_dimensions[celda].width = value
    if (flag == 1):
        sheet.row_dimensions[int(celda)].height = value

def crear_reportEntrada(sheet,item_acc,fecha_desde,fecha_hasta):
            
    ajustar_hoja_entrada(sheet, 0, 'A', 4.00)  
    ajustar_hoja_entrada(sheet, 0, 'B', 10.00)
    ajustar_hoja_entrada(sheet, 0, 'C', 10.00)     
    ajustar_hoja_entrada(sheet, 0, 'D', 25.00)
    ajustar_hoja_entrada(sheet, 0, 'E', 25.00)
    ajustar_hoja_entrada(sheet, 0, 'F', 25.00)
    ajustar_hoja_entrada(sheet, 0, 'G', 25.00)
    ajustar_hoja_entrada(sheet, 0, 'H', 25.00)
    ajustar_hoja_entrada(sheet, 0, 'I', 25.00)
    ajustar_hoja_entrada(sheet, 0, 'J', 28.00)
    ajustar_hoja_entrada(sheet, 0, 'k', 32.00)
    ajustar_hoja_entrada(sheet, 0, 'O', 15.00)
    ajustar_hoja_entrada(sheet, 0, 'P', 15.00)
    ajustar_hoja_entrada(sheet, 0, 'V', 40.00)
    ajustar_hoja_entrada(sheet, 1, '1', 40.00)
    ajustar_hoja_entrada(sheet, 1, '2', 40.00)
    ajustar_hoja_entrada(sheet, 1, '3', 20.00)
    ajustar_hoja_entrada(sheet, 1, '4', 20.00)
    ajustar_hoja_entrada(sheet, 1, '6', 30.00)

    alignment_title = Alignment(horizontal='center', vertical='center')
    alignment_title1 = Alignment(horizontal='right', vertical='center')
    alignment_title2 = Alignment(horizontal='left', vertical='center')

    fuente_cabecera = Font(bold=True, size=12, name='calibri',)
    
    ##---------------BORDE----------------###############
    ##Todalatabla(sheet,2,9,4,5,'thin','thin','thin','thin')
    ############IMAGE##################
    
    #// comentado por andy
    img_c = Image('/mnt/extra-addons/app_emelec/static/src/img/emelec.png', size=(100, 90))
    img_c.anchor(sheet.cell(row=1, column=2),'oneCell')
    sheet.add_image(img_c)

    sheet.merge_cells('E1:I1')
    sheet['E1'].alignment = alignment_title.copy(wrapText=True)
    sheet['E1'].font = fuente_cabecera.copy(bold=True,size=36, name= "calibri")
    sheet['E1']= 'REPORTE DE ENTRADAS'

    sheet.merge_cells('E2:I2')
    sheet['E2'].alignment = alignment_title.copy(wrapText=True)
    sheet['E2'].font = fuente_cabecera.copy(bold=True,size=26, name= "calibri")
    sheet['E2']= 'Club Sport Emelec'    

    sheet.merge_cells('B3:C3')
    sheet['B3'].alignment = alignment_title.copy(wrapText=True)
    sheet['B3'].font = fuente_cabecera.copy(bold=True,size=14, name= "calibri")
    sheet['B3']= 'Fecha desde:' 

    sheet.merge_cells('B4:C4')
    sheet['B4'].alignment = alignment_title.copy(wrapText=True)
    sheet['B4'].font = fuente_cabecera.copy(bold=True,size=14, name= "calibri")
    sheet['B4']= 'Fecha Hasta:' 

    sheet.merge_cells('B6:C6')
    sheet['B6'].alignment = alignment_title.copy(wrapText=True)
    sheet['B6'].font = fuente_cabecera.copy(bold=True,size=14, name= "calibri")
    sheet['B6'].fill = PatternFill(fill_type="solid", fgColor='aba7a7')
    sheet['B6']= 'Cédula cliente'
    border_cell(sheet, 6, 2, 'thin', 'thin', 'thin', 'thin')
    border_cell(sheet, 6, 3, 'thin', 'thin', 'thin', 'thin')

    sheet.merge_cells('D6')
    sheet['D6'].alignment = alignment_title.copy(wrapText=True)
    sheet['D6'].font = fuente_cabecera.copy(bold=True,size=14, name= "calibri")
    sheet['D6'].fill = PatternFill(fill_type="solid", fgColor='aba7a7')
    sheet['D6']= 'Número Entrada'
    border_cell(sheet, 6, 4, 'thin', 'thin', 'thin', 'thin')

    sheet.merge_cells('E6')
    sheet['E6'].alignment = alignment_title.copy(wrapText=True)
    sheet['E6'].font = fuente_cabecera.copy(bold=True,size=14, name= "calibri")
    sheet['E6'].fill = PatternFill(fill_type="solid", fgColor='aba7a7')
    sheet['E6']= 'Fecha Compra'
    border_cell(sheet, 6, 5, 'thin', 'thin', 'thin', 'thin')

    sheet.merge_cells('F6')
    sheet['F6'].alignment = alignment_title.copy(wrapText=True)
    sheet['F6'].font = fuente_cabecera.copy(bold=True,size=14, name= "calibri")
    sheet['F6'].fill = PatternFill(fill_type="solid", fgColor='aba7a7')
    sheet['F6']= 'Partido'
    border_cell(sheet, 6, 6, 'thin', 'thin', 'thin', 'thin')

    #sheet.merge_cells('F6:G6')
    sheet['G6'].alignment = alignment_title.copy(wrapText=True)
    sheet['G6'].font = fuente_cabecera.copy(bold=True,size=14, name= "calibri")
    sheet['G6'].fill = PatternFill(fill_type="solid", fgColor='aba7a7')
    sheet['G6']= 'Localidad'
    #border_cell(sheet, 6, 6, 'thin', 'thin', 'thin', 'thin')
    border_cell(sheet, 6, 7, 'thin', 'thin', 'thin', 'thin')

    sheet['H6'].alignment = alignment_title.copy(wrapText=True)
    sheet['H6'].font = fuente_cabecera.copy(bold=True,size=14, name= "calibri")
    sheet['H6'].fill = PatternFill(fill_type="solid", fgColor='aba7a7')
    sheet['H6']= 'Estado'
    border_cell(sheet, 6, 8, 'thin', 'thin', 'thin', 'thin')

    sheet['I6'].alignment = alignment_title.copy(wrapText=True)
    sheet['I6'].font = fuente_cabecera.copy(bold=True,size=14, name= "calibri")
    sheet['I6'].fill = PatternFill(fill_type="solid", fgColor='aba7a7')
    sheet['I6']= 'Beneficiario'
    border_cell(sheet, 6, 9, 'thin', 'thin', 'thin', 'thin')

    # sheet['J6'].alignment = alignment_title.copy(wrapText=True)
    # sheet['J6'].font = fuente_cabecera.copy(bold=True,size=14, name= "calibri")
    # sheet['J6'].fill = PatternFill(fill_type="solid", fgColor='aba7a7')
    # sheet['J6']= 'Valor Entradas(Millas)'
    # border_cell(sheet, 6, 10, 'thin', 'thin', 'thin', 'thin')
    
    # sheet['K6'].alignment = alignment_title.copy(wrapText=True)
    # sheet['K6'].font = fuente_cabecera.copy(bold=True,size=14, name= "calibri")
    # sheet['K6'].fill = PatternFill(fill_type="solid", fgColor='aba7a7')
    # sheet['K6']= 'Número canje/ Aprobación'
    # border_cell(sheet, 6, 11, 'thin', 'thin', 'thin', 'thin')

    sheet['D3'].alignment = alignment_title2.copy(wrapText=True)
    sheet['D3'].font = fuente_cabecera.copy(bold=False,size=14, name= "calibri")
    sheet['D3']= str(fecha_desde)
    border_cell(sheet, 3, 3, 'thin', 'thin', 'thin', 'thin')

    sheet['D4'].alignment = alignment_title2.copy(wrapText=True)
    sheet['D4'].font = fuente_cabecera.copy(bold=False,size=14, name= "calibri")
    sheet['D4']= str(fecha_hasta)
    border_cell(sheet, 4, 3, 'thin', 'thin', 'thin', 'thin')

    fila1=7
    for x in item_acc:
        ajustar_hoja_entrada(sheet, 1, fila1, 45.00)
        sheet.merge_cells('B'+str(fila1)+':'+'C'+str(fila1))
        sheet['B'+str(fila1)].alignment = alignment_title.copy(wrapText=True)
        sheet['B'+str(fila1)].font = fuente_cabecera.copy(bold=False,size=12, name= "calibri")
        sheet['B'+str(fila1)]= x['cedula']
        border_cell(sheet, fila1, 2, 'thin', 'thin', 'thin', 'thin')
        border_cell(sheet, fila1, 3, 'thin', 'thin', 'thin', 'thin')

        #sheet.merge_cells('E'+str(fila1)+':'+'G'+str(fila1))
        sheet['D'+str(fila1)].alignment = alignment_title.copy(wrapText=True)
        sheet['D'+str(fila1)].font = fuente_cabecera.copy(bold=False,size=12, name= "calibri")
        #sheet['E'+str(fila1)].fill = PatternFill(fill_type="solid", fgColor='bbb6b6')
        sheet['D'+str(fila1)]= x['num_entrada']
        border_cell(sheet, fila1, 4, 'thin', 'thin', 'thin', 'thin')

        sheet['E'+str(fila1)].alignment = alignment_title.copy(wrapText=True)
        sheet['E'+str(fila1)].font = fuente_cabecera.copy(bold=False,size=12, name= "calibri")
        sheet['E'+str(fila1)]= x['data_order_']
        border_cell(sheet, fila1, 5, 'thin', 'thin', 'thin', 'thin')

        sheet['F'+str(fila1)].alignment = alignment_title.copy(wrapText=True)
        sheet['F'+str(fila1)].font = fuente_cabecera.copy(bold=False,size=12, name= "calibri")
        #sheet['H'+str(fila1)].fill = PatternFill(fill_type="solid", fgColor='bbb6b6')
        sheet['F'+str(fila1)]= x['name']
        border_cell(sheet, fila1, 6, 'thin', 'thin', 'thin', 'thin')

        # sheet.merge_cells('F'+str(fila1)+':'+'G'+str(fila1))
        sheet['G'+str(fila1)].alignment = alignment_title.copy(wrapText=True)
        sheet['G'+str(fila1)].font = fuente_cabecera.copy(bold=False,size=12, name= "calibri")
        #sheet['K'+str(fila1)].fill = PatternFill(fill_type="solid", fgColor='bbb6b6')
        sheet['G'+str(fila1)]= x['localidad']
       # border_cell(sheet, fila1, 6, 'thin', 'thin', 'thin', 'thin')
        border_cell(sheet, fila1, 7, 'thin', 'thin', 'thin', 'thin')

        sheet['H'+str(fila1)].alignment = alignment_title.copy(wrapText=True)
        sheet['H'+str(fila1)].font = fuente_cabecera.copy(bold=False,size=12, name= "calibri")
        #sheet['K'+str(fila1)].fill = PatternFill(fill_type="solid", fgColor='bbb6b6')
        sheet['H'+str(fila1)]= x['estado']
        border_cell(sheet, fila1, 8, 'thin', 'thin', 'thin', 'thin')

        sheet['I'+str(fila1)].alignment = alignment_title.copy(wrapText=True)
        sheet['I'+str(fila1)].font = fuente_cabecera.copy(bold=False,size=12, name= "calibri")
        #sheet['K'+str(fila1)].fill = PatternFill(fill_type="solid", fgColor='bbb6b6')
        sheet['I'+str(fila1)]= x['beneficiario']
        border_cell(sheet, fila1, 9, 'thin', 'thin', 'thin', 'thin')

        fila1=fila1+1



def Todalatabla(sheet, col, colfin, fil, filfin, styleleft, styletop, styleright, stylebottom):

    colfin=colfin+1
    filfin=filfin+2

    border_cell = Border(left=Side(style=styleleft), top=Side(style=styletop), right=Side(style=styleright), bottom=Side(style=stylebottom))
    for i in range(fil, filfin-1):
        for j in range(col, colfin):
            sheet.cell(row=i, column=j).border = border_cell
    
def border_cell(sheet, fil, col, styleleft, styletop, styleright, stylebottom):
    border_cell = Border(left=Side(style=styleleft), top=Side(style=styletop), right=Side(style=styleright), bottom=Side(style=stylebottom))
    sheet.cell(row=fil, column=col).border = border_cell



