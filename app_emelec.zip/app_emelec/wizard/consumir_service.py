# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

import requests
from getpass import getpass
# Definimos la URL

class consumir_service():
	_name='consumir.service'

	def consumir_service():
		url = "http://10.35.2.38:8080/consultarToken"
		# Definimos la cabecera y el diccionario con los datos
		cabecera1 = {'Content-type': 'application/json'}
		#datos = '{"auth":{"passwordCredentials":{"username": "%s", "password": "%s"}, "tenantName":"%s"}}' % (user, passwd, proy)
		datos = '{"cedula":"0923009138"}'
		solicitud = requests.post(url, headers = cabecera1, data = datos)
		if solicitud.status_code == 200:
		    print solicitud.text