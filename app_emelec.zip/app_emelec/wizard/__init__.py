# -*- coding: utf-8 -*-

import report_ventas_
import reporte_entrada
import consumir_service