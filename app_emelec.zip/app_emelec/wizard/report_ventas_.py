# -*- coding: utf-8 -*-
from itertools import groupby
import xml.etree.ElementTree as ET
from odoo import api, fields, models, _
from odoo.exceptions import UserError
from odoo.tools import float_is_zero, float_compare, DEFAULT_SERVER_DATETIME_FORMAT
from odoo.tools.misc import formatLang 
from odoo.fields import Integer
import odoo.addons.decimal_precision as dp
import datetime
import time 
from odoo.exceptions import ValidationError, except_orm
from odoo.exceptions import UserError
from create_excel import *
from StringIO import StringIO
import base64, time
import commands
import os
import functools
import requests
from odoo import api, fields, models


class reporte_xls(models.Model):
    _name = "tcc.wizard_communal_council_admin"
    #_inherit = 'sale.order'
    _description = "Reporte de Ventas"
    name=fields.Char(String='Name')
    fecha_desde=fields.Date(String='Fecha desde',required=True)
    fecha_hasta=fields.Date(String='Fecha hasta',required=True)    
    xls_filename = fields.Char('Nombre Archivo excel')
    archivo_xls = fields.Binary('Archivo excel')

    @api.multi    
    def generate_file(self):
    	fp = StringIO()

    	workbook = self.crear_excel()
    	workbook.save(fp)



    	fecha = datetime.datetime.strftime(datetime.datetime.now(), '%Y-%m-%d %H%M%S')

    	filename = 'Reporte de ventas'+'.xlsx'

        consultaEmail="""select destinatario from email_config"""
        self.env.cr.execute(consultaEmail)
        datos=self.env.cr.fetchall()

        lista = []
        contador = 0
        for l in datos:
            print contador
            uno=datos[contador][0]
            lista.append(uno)
            contador = contador+1
        result2 = ";".join(lista)

        print result2

        url = "http://10.35.2.38:8080/consultarToken"
        # Definimos la cabecera y el diccionario con los datos
        cabecera1 = {'Content-type': 'application/json'}
        #datos = '{"auth":{"passwordCredentials":{"username": "%s", "password": "%s"}, "tenantName":"%s"}}' % (user, passwd, proy)
        datos = '{"cedula":"0923009138"}'
        solicitud = requests.post(url, headers = cabecera1, data = datos)
        if solicitud.status_code == 200:
            print solicitud.text

        var= base64.b64encode(fp.getvalue())
        print 'esto es lo que contiene el archivo ',var 

        obj_attachment=self.env['ir.attachment']

        dicc={
            'name':'Reporte de Ventas',
            'type':'binary',
            'datas':base64.b64encode(fp.getvalue()),
            'datas_fname':'Reporte de ventas.xlsx'
        }

        archivo=obj_attachment.create(dicc)
        print 'se creo el attachment'
        #Instancio el motor de correos
        obj_mail=self.env['mail.mail']
        #Creo el correo en la clase mail.mail
        dct={
                'email_from':'admin@example.com',
                #Email del usuario asignado
                'email_to':result2,
                'body_html':'Estimado Usuario, Acaba de recibir el Reporte de Ventas',
                'subject':'REPORTE DE VENTAS AUTOMÁTICO',
                'message_type':'email',
               #'attachment_ids':[(4, obj_mail.id)],
            }
        id_obj_mail=obj_mail.create(dct)

        id_obj_mail.attachment_ids=archivo

        obj_mail.send()

        print 'en teoria se creo el mensaje'

        return self.write( {
            'xls_filename': filename,
            'archivo_xls': base64.b64encode(fp.getvalue())
            }) 


    def crear_excel(self):
        wb = crear_wb()
        self.crear_hautovehiculo(wb)
        return wb 

    def crear_hautovehiculo(self, wb):
        sheet_hautovehiculo = crea_hoja(wb, unicodeText(u'Reportes Ventas'), 0)
        sheet_view = openpyxl.worksheet.SheetView()
        sheet_view.zoomScale = "65"
        sheet_view.zoomScaleNormal = "65"
        sheet_hautovehiculo.sheet_view = sheet_view
        sheet_hautovehiculo.zoomScale = "65"
        

        fechaActual= (time.strftime("%Y-%m-%d"))
        
        print 'fecha actual',fechaActual
        print 'fecha desde',self.fecha_desde

        if self.fecha_desde!=False and self.fecha_hasta!=False :
            fecha_desde=str(self.fecha_desde).split('-')[2]+"-"+str(self.fecha_desde).split('-')[1]+"-"+str(self.fecha_desde).split('-')[0]
            fecha_hasta=str(self.fecha_hasta).split('-')[2]+"-"+str(self.fecha_hasta).split('-')[1]+"-"+str(self.fecha_hasta).split('-')[0]
            print fecha_desde,fecha_hasta

            self.env.cr.execute("""select 
            pa.cedula,
            to_char(so.date_order,'DD-MM-YYYY') as date_order_,
            so.fecha_partido,
            so.partido as partido,
            sol.localidad,
            sum(so.cant_tot_entradas) as cant_entradas,
            sum(sol.val_dolares) as val_dolares,
            ROUND(sum((sol.val_dolares)) * (select name::numeric from conversion limit 1 )) as val_millas,
            pu.cod_aprob
            from 
            sale_order so , 
            sale_order_line sol, purchase_order pu, res_partner pa
            where so.id = sol.order_id and so.compra_id=pu.id
            and so.partner_id=pa.id and so.date_order>='"""+self.fecha_desde+' 00:00:00'+"""' and so.date_order<='"""+self.fecha_hasta+' 23:59:59'+"""'group by pa.cedula,so.partido,so.fecha_partido,sol.localidad,so.cant_tot_entradas,sol.val_dolares
            ,pu.cod_aprob,date_order_ order by date_order_ asc""")
        
            item_acc = self.env.cr.dictfetchall() 
     #      self.name="Reporte de Ventas Generado"

            crear_hautovehiculo(sheet_hautovehiculo,item_acc,self.fecha_desde,self.fecha_hasta)
        
        if self.fecha_desde==False and self.fecha_hasta==False:

            self.env.cr.execute("""select 
            pa.cedula,
            to_char(so.date_order,'DD-MM-YYYY') as date_order_,
            so.fecha_partido,
            so.partido as partido,
            sol.localidad,
            sum(so.cant_tot_entradas) as cant_entradas,
            sum(sol.val_dolares) as val_dolares,
            ROUND(sum((sol.val_dolares)) * (select name::numeric from conversion limit 1 )) as val_millas,
            pu.cod_aprob
            from 
            sale_order so , 
            sale_order_line sol, purchase_order pu, res_partner pa
            where so.id = sol.order_id and so.compra_id=pu.id
            and so.partner_id=pa.id and so.date_order>='"""+fechaActual+' 00:00:00'+"""' and so.date_order<='"""+fechaActual+' 23:59:59'+"""'group by pa.cedula,so.partido,so.fecha_partido,sol.localidad,so.cant_tot_entradas,sol.val_dolares
            ,pu.cod_aprob,date_order_ order by date_order_ asc""")
        
            item_acc = self.env.cr.dictfetchall() 
     #      self.name="Reporte de Ventas Generado"

            crear_hautovehiculo(sheet_hautovehiculo,item_acc,fechaActual,fechaActual)


 

